#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Moodify Cloud Night Worker
--------------------------
目的：
  在云服务器夜间自动批量处理 AI 音乐样本，生成日志、manifest、summary。
原则：
  1. 不侵入 moodify 核心代码。
  2. 默认只通过现有 CLI 命令调用工程。
  3. 失败可追踪，第二天可以复盘。
  4. 支持 dry-run / smoke test / resume。
"""

from __future__ import annotations

import argparse
import csv
import datetime as dt
import json
import os
import shlex
import shutil
import subprocess
import sys
import time
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Tuple


AUDIO_SUFFIXES = {".wav", ".mp3", ".flac", ".m4a", ".aac", ".ogg"}


DEFAULT_CONFIG: Dict[str, Any] = {
    "project_root": ".",
    "input_dir": "data/night_inputs",
    "output_base_dir": "outputs/night_runs",
    "presets": ["warm_vocal", "clean_master", "wide_space"],
    "max_files": 30,
    "recurse": False,
    "timeout_seconds_per_task": 900,
    "sleep_seconds_between_tasks": 2,
    "python": sys.executable,
    "stop_on_first_success_template": True,
    "preflight_commands": [
        "{python} --version",
        "{python} cli.py --help"
    ],
    "command_templates": [
        "{python} cli.py process --input {input} --output {output_dir} --preset {preset}",
        "{python} -m moodify.cli process --input {input} --output {output_dir} --preset {preset}",
        "{python} cli.py process {input} --output {output_dir} --preset {preset}"
    ],
    "env": {
        "PYTHONUNBUFFERED": "1",
        "MOODIFY_NIGHT_RUN": "1"
    }
}


def now_stamp() -> str:
    return dt.datetime.now().strftime("%Y%m%d_%H%M%S")


def load_config(path: Optional[Path]) -> Dict[str, Any]:
    cfg = dict(DEFAULT_CONFIG)
    if path:
        with path.open("r", encoding="utf-8") as f:
            user_cfg = json.load(f)
        cfg = deep_merge(cfg, user_cfg)
    return cfg


def deep_merge(a: Dict[str, Any], b: Dict[str, Any]) -> Dict[str, Any]:
    out = dict(a)
    for k, v in b.items():
        if isinstance(v, dict) and isinstance(out.get(k), dict):
            out[k] = deep_merge(out[k], v)
        else:
            out[k] = v
    return out


def resolve_path(project_root: Path, p: str | Path) -> Path:
    p = Path(p)
    if p.is_absolute():
        return p
    return project_root / p


def discover_audio(input_dir: Path, recurse: bool, max_files: int) -> List[Path]:
    if not input_dir.exists():
        return []
    iterator = input_dir.rglob("*") if recurse else input_dir.glob("*")
    files = sorted(
        [p for p in iterator if p.is_file() and p.suffix.lower() in AUDIO_SUFFIXES],
        key=lambda x: x.name.lower()
    )
    if max_files and max_files > 0:
        files = files[:max_files]
    return files


class NightLogger:
    def __init__(self, log_path: Path) -> None:
        self.log_path = log_path
        self.log_path.parent.mkdir(parents=True, exist_ok=True)

    def write(self, msg: str) -> None:
        line = f"[{dt.datetime.now().isoformat(timespec='seconds')}] {msg}"
        print(line, flush=True)
        with self.log_path.open("a", encoding="utf-8") as f:
            f.write(line + "\n")


def format_command(template: str, ctx: Dict[str, str]) -> List[str]:
    rendered = template.format(**ctx)
    return shlex.split(rendered)


def run_subprocess(
    cmd: List[str],
    cwd: Path,
    env: Dict[str, str],
    timeout: int,
    logger: NightLogger,
) -> Tuple[int, str, str, float]:
    start = time.time()
    logger.write("RUN " + " ".join(shlex.quote(x) for x in cmd))
    try:
        proc = subprocess.run(
            cmd,
            cwd=str(cwd),
            env=env,
            text=True,
            capture_output=True,
            timeout=timeout,
        )
        elapsed = time.time() - start
        stdout = proc.stdout[-4000:] if proc.stdout else ""
        stderr = proc.stderr[-4000:] if proc.stderr else ""
        if stdout.strip():
            logger.write("STDOUT(last 4000 chars):\n" + stdout.strip())
        if stderr.strip():
            logger.write("STDERR(last 4000 chars):\n" + stderr.strip())
        return proc.returncode, stdout, stderr, elapsed
    except subprocess.TimeoutExpired as e:
        elapsed = time.time() - start
        logger.write(f"TIMEOUT after {elapsed:.1f}s")
        return 124, e.stdout or "", e.stderr or "", elapsed
    except Exception as e:
        elapsed = time.time() - start
        logger.write(f"EXCEPTION {type(e).__name__}: {e}")
        return 125, "", str(e), elapsed


def acquire_lock(lock_path: Path) -> None:
    lock_path.parent.mkdir(parents=True, exist_ok=True)
    try:
        fd = os.open(str(lock_path), os.O_CREAT | os.O_EXCL | os.O_WRONLY)
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            f.write(f"pid={os.getpid()}\ntime={dt.datetime.now().isoformat()}\n")
    except FileExistsError:
        raise RuntimeError(
            f"Night worker lock already exists: {lock_path}\n"
            "如果确认没有旧任务在跑，可以手动删除这个 lock 文件。"
        )


def release_lock(lock_path: Path) -> None:
    try:
        lock_path.unlink(missing_ok=True)
    except Exception:
        pass


def write_json(path: Path, obj: Dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(obj, ensure_ascii=False, indent=2), encoding="utf-8")


def update_latest_symlink(output_base_dir: Path, run_dir: Path) -> None:
    latest = output_base_dir / "latest"
    try:
        if latest.exists() or latest.is_symlink():
            if latest.is_symlink() or latest.is_file():
                latest.unlink()
            else:
                # Windows or unusual FS fallback: leave directory alone
                return
        latest.symlink_to(run_dir.name, target_is_directory=True)
    except Exception:
        # 不影响主流程
        pass


def preflight(cfg: Dict[str, Any], project_root: Path, env: Dict[str, str], logger: NightLogger, dry_run: bool) -> None:
    logger.write("PREFLIGHT start")
    logger.write(f"project_root={project_root}")
    logger.write(f"python={cfg['python']}")
    if not project_root.exists():
        raise RuntimeError(f"project_root does not exist: {project_root}")

    for template in cfg.get("preflight_commands", []):
        ctx = {
            "python": cfg["python"],
            "project_root": str(project_root),
        }
        try:
            cmd = format_command(template, ctx)
        except KeyError as e:
            logger.write(f"Skip invalid preflight template {template}: missing {e}")
            continue
        if dry_run:
            logger.write("[DRY-RUN] preflight " + " ".join(cmd))
            continue
        code, _, _, _ = run_subprocess(cmd, project_root, env, 60, logger)
        if code != 0:
            logger.write(f"WARNING preflight command failed with code={code}: {template}")
    logger.write("PREFLIGHT end")


def init_manifest(path: Path) -> None:
    if path.exists():
        return
    with path.open("w", encoding="utf-8", newline="") as f:
        writer = csv.DictWriter(
            f,
            fieldnames=[
                "run_id", "audio", "preset", "status", "return_code",
                "elapsed_seconds", "output_dir", "template_index", "error"
            ],
        )
        writer.writeheader()


def append_manifest(path: Path, row: Dict[str, Any]) -> None:
    with path.open("a", encoding="utf-8", newline="") as f:
        writer = csv.DictWriter(
            f,
            fieldnames=[
                "run_id", "audio", "preset", "status", "return_code",
                "elapsed_seconds", "output_dir", "template_index", "error"
            ],
        )
        writer.writerow(row)


def task_done_marker(output_dir: Path) -> Path:
    return output_dir / ".moodify_night_done"


def main() -> int:
    parser = argparse.ArgumentParser(description="Moodify Cloud Night Worker")
    parser.add_argument("--config", type=str, default=None, help="JSON 配置文件路径")
    parser.add_argument("--project-root", type=str, default=None, help="覆盖 project_root")
    parser.add_argument("--input-dir", type=str, default=None, help="覆盖 input_dir")
    parser.add_argument("--output-base-dir", type=str, default=None, help="覆盖 output_base_dir")
    parser.add_argument("--max-files", type=int, default=None, help="覆盖最大处理文件数")
    parser.add_argument("--smoke", action="store_true", help="只跑 1 个音频 × 1 个 preset，用于上云前测试")
    parser.add_argument("--dry-run", action="store_true", help="只打印计划，不执行处理")
    parser.add_argument("--resume", action="store_true", help="已完成的任务自动跳过")
    args = parser.parse_args()

    cfg = load_config(Path(args.config) if args.config else None)
    if args.project_root:
        cfg["project_root"] = args.project_root
    if args.input_dir:
        cfg["input_dir"] = args.input_dir
    if args.output_base_dir:
        cfg["output_base_dir"] = args.output_base_dir
    if args.max_files is not None:
        cfg["max_files"] = args.max_files

    project_root = Path(cfg["project_root"]).resolve()
    input_dir = resolve_path(project_root, cfg["input_dir"]).resolve()
    output_base_dir = resolve_path(project_root, cfg["output_base_dir"]).resolve()
    run_id = now_stamp()
    run_dir = output_base_dir / run_id
    run_dir.mkdir(parents=True, exist_ok=True)

    logger = NightLogger(run_dir / "night_worker.log")
    lock_path = output_base_dir / "night_worker.lock"
    manifest_path = run_dir / "manifest.csv"
    summary_path = run_dir / "summary.json"

    update_latest_symlink(output_base_dir, run_dir)
    init_manifest(manifest_path)

    env = os.environ.copy()
    env.update({str(k): str(v) for k, v in cfg.get("env", {}).items()})
    existing_pythonpath = env.get("PYTHONPATH", "")
    env["PYTHONPATH"] = str(project_root) + (os.pathsep + existing_pythonpath if existing_pythonpath else "")

    summary: Dict[str, Any] = {
        "run_id": run_id,
        "started_at": dt.datetime.now().isoformat(timespec="seconds"),
        "project_root": str(project_root),
        "input_dir": str(input_dir),
        "run_dir": str(run_dir),
        "dry_run": args.dry_run,
        "smoke": args.smoke,
        "total_tasks": 0,
        "success": 0,
        "failed": 0,
        "skipped": 0,
        "files": [],
    }

    try:
        acquire_lock(lock_path)
        logger.write("Moodify Cloud Night Worker START")
        preflight(cfg, project_root, env, logger, args.dry_run)

        files = discover_audio(input_dir, bool(cfg.get("recurse")), int(cfg.get("max_files", 0) or 0))
        presets = list(cfg.get("presets") or [])
        if args.smoke:
            files = files[:1]
            presets = presets[:1] if presets else ["warm_vocal"]

        logger.write(f"Discovered audio files: {len(files)}")
        logger.write(f"Presets: {presets}")

        if not files:
            logger.write("No audio files found. Put wav/mp3/flac files into input_dir.")
            summary["error"] = "no_audio_files"
            write_json(summary_path, summary)
            return 2

        write_json(run_dir / "effective_config.json", cfg)

        for audio in files:
            for preset in presets:
                stem_safe = audio.stem.replace(" ", "_")
                task_output_dir = run_dir / stem_safe / preset
                task_output_dir.mkdir(parents=True, exist_ok=True)
                done_marker = task_done_marker(task_output_dir)

                summary["total_tasks"] += 1
                ctx = {
                    "python": str(cfg["python"]),
                    "project_root": str(project_root),
                    "input": str(audio),
                    "output_dir": str(task_output_dir),
                    "preset": str(preset),
                    "stem": stem_safe,
                    "timestamp": run_id,
                    "run_id": run_id,
                }

                if args.resume and done_marker.exists():
                    logger.write(f"SKIP done audio={audio.name} preset={preset}")
                    summary["skipped"] += 1
                    append_manifest(manifest_path, {
                        "run_id": run_id,
                        "audio": str(audio),
                        "preset": preset,
                        "status": "skipped",
                        "return_code": "",
                        "elapsed_seconds": "",
                        "output_dir": str(task_output_dir),
                        "template_index": "",
                        "error": "",
                    })
                    continue

                if args.dry_run:
                    for i, template in enumerate(cfg.get("command_templates", [])):
                        logger.write(f"[DRY-RUN] template#{i}: " + template.format(**ctx))
                    append_manifest(manifest_path, {
                        "run_id": run_id,
                        "audio": str(audio),
                        "preset": preset,
                        "status": "dry_run",
                        "return_code": "",
                        "elapsed_seconds": "",
                        "output_dir": str(task_output_dir),
                        "template_index": "",
                        "error": "",
                    })
                    continue

                task_ok = False
                last_error = ""
                last_code = ""
                last_elapsed = 0.0
                last_template_index = ""

                for i, template in enumerate(cfg.get("command_templates", [])):
                    try:
                        cmd = format_command(template, ctx)
                    except KeyError as e:
                        last_error = f"template missing key: {e}"
                        logger.write(f"Invalid template#{i}: {last_error}")
                        continue

                    code, stdout, stderr, elapsed = run_subprocess(
                        cmd=cmd,
                        cwd=project_root,
                        env=env,
                        timeout=int(cfg.get("timeout_seconds_per_task", 900)),
                        logger=logger,
                    )
                    last_code = code
                    last_elapsed = elapsed
                    last_template_index = i
                    if code == 0:
                        task_ok = True
                        done_marker.write_text(
                            f"done_at={dt.datetime.now().isoformat(timespec='seconds')}\n"
                            f"audio={audio}\npreset={preset}\ntemplate_index={i}\n",
                            encoding="utf-8",
                        )
                        break
                    else:
                        last_error = (stderr or stdout or f"return_code={code}")[-500:]

                    if cfg.get("stop_on_first_success_template", True) is False:
                        # 如果用户想比较多个模板，可以关闭；默认成功即停止。
                        pass

                if task_ok:
                    logger.write(f"SUCCESS audio={audio.name} preset={preset}")
                    summary["success"] += 1
                    status = "success"
                    error = ""
                else:
                    logger.write(f"FAILED audio={audio.name} preset={preset} error={last_error}")
                    summary["failed"] += 1
                    status = "failed"
                    error = last_error

                append_manifest(manifest_path, {
                    "run_id": run_id,
                    "audio": str(audio),
                    "preset": preset,
                    "status": status,
                    "return_code": last_code,
                    "elapsed_seconds": f"{last_elapsed:.2f}",
                    "output_dir": str(task_output_dir),
                    "template_index": last_template_index,
                    "error": error,
                })

                time.sleep(float(cfg.get("sleep_seconds_between_tasks", 0)))

        summary["finished_at"] = dt.datetime.now().isoformat(timespec="seconds")
        write_json(summary_path, summary)
        logger.write("Moodify Cloud Night Worker FINISH")
        logger.write(f"Summary: success={summary['success']} failed={summary['failed']} skipped={summary['skipped']}")
        return 0 if summary["failed"] == 0 else 1

    except Exception as e:
        summary["finished_at"] = dt.datetime.now().isoformat(timespec="seconds")
        summary["fatal_error"] = f"{type(e).__name__}: {e}"
        write_json(summary_path, summary)
        logger.write(f"FATAL {type(e).__name__}: {e}")
        return 99
    finally:
        release_lock(lock_path)


if __name__ == "__main__":
    raise SystemExit(main())
