#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT_DIR"

CONFIG="${1:-configs/runtime_config.json}"

python3 -m moodify_runtime.cli --config "$CONFIG" register --source "smoke_test"
python3 -m moodify_runtime.cli --config "$CONFIG" plan --max-new-tasks 1
python3 -m moodify_runtime.cli --config "$CONFIG" run --limit 1 --dry-run
