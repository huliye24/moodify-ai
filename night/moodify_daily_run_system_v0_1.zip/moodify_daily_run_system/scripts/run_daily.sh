#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT_DIR"

if [ -f ".venv/bin/activate" ]; then
  source .venv/bin/activate
elif [ -f "venv/bin/activate" ]; then
  source venv/bin/activate
fi

CONFIG="${1:-configs/runtime_config.json}"

python3 -m moodify_runtime.cli --config "$CONFIG" register --source "daily_input"
python3 -m moodify_runtime.cli --config "$CONFIG" plan
python3 -m moodify_runtime.cli --config "$CONFIG" run
python3 -m moodify_runtime.cli --config "$CONFIG" report
python3 -m moodify_runtime.cli --config "$CONFIG" craft
python3 -m moodify_runtime.cli --config "$CONFIG" next
