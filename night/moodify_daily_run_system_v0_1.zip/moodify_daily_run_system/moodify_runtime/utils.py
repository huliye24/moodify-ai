from __future__ import annotations

import csv
import datetime as dt
import hashlib
import json
import os
import shlex
import subprocess
import time
from pathlib import Path
from typing import Any, Dict, Iterable, Iterator, List, Optional, Tuple


def utc_now_iso() -> str:
    return dt.datetime.utcnow().replace(microsecond=0).isoformat() + "Z"


def local_stamp() -> str:
    return dt.datetime.now().strftime("%Y%m%d_%H%M%S")


def ensure_parent(path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)


def read_jsonl(path: Path) -> List[Dict[str, Any]]:
    if not path.exists():
        return []
    rows = []
    with path.open("r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            rows.append(json.loads(line))
    return rows


def append_jsonl(path: Path, obj: Dict[str, Any]) -> None:
    ensure_parent(path)
    with path.open("a", encoding="utf-8") as f:
        f.write(json.dumps(obj, ensure_ascii=False, sort_keys=False) + "\n")


def write_json(path: Path, obj: Any) -> None:
    ensure_parent(path)
    path.write_text(json.dumps(obj, ensure_ascii=False, indent=2), encoding="utf-8")


def read_json(path: Path, default: Any = None) -> Any:
    if not path.exists():
        return default
    return json.loads(path.read_text(encoding="utf-8"))


def file_sha1(path: Path, max_bytes: Optional[int] = None) -> str:
    h = hashlib.sha1()
    with path.open("rb") as f:
        if max_bytes is None:
            for chunk in iter(lambda: f.read(1024 * 1024), b""):
                h.update(chunk)
        else:
            remaining = max_bytes
            while remaining > 0:
                chunk = f.read(min(1024 * 1024, remaining))
                if not chunk:
                    break
                h.update(chunk)
                remaining -= len(chunk)
    return h.hexdigest()


def stable_sample_id(path: Path) -> str:
    # 用文件头 + 大小 + 文件名做稳定 ID，避免大文件全量 hash 太慢
    stat = path.stat()
    h = hashlib.sha1()
    h.update(path.name.encode("utf-8", errors="ignore"))
    h.update(str(stat.st_size).encode())
    h.update(file_sha1(path, max_bytes=2 * 1024 * 1024).encode())
    return "SMP_" + h.hexdigest()[:16].upper()


def discover_audio_files(input_dirs: Iterable[Path], suffixes: Iterable[str], recurse: bool, max_files: int = 0) -> List[Path]:
    suffix_set = {s.lower() for s in suffixes}
    files: List[Path] = []
    for input_dir in input_dirs:
        if not input_dir.exists():
            continue
        iterator = input_dir.rglob("*") if recurse else input_dir.glob("*")
        for p in iterator:
            if p.is_file() and p.suffix.lower() in suffix_set:
                files.append(p)
    files = sorted(set(files), key=lambda x: str(x).lower())
    if max_files and max_files > 0:
        files = files[:max_files]
    return files


def quote_cmd(cmd: List[str]) -> str:
    return " ".join(shlex.quote(x) for x in cmd)


def run_command(cmd: List[str], cwd: Path, env: Dict[str, str], timeout: int) -> Dict[str, Any]:
    start = time.time()
    try:
        proc = subprocess.run(
            cmd,
            cwd=str(cwd),
            env=env,
            text=True,
            capture_output=True,
            timeout=timeout,
        )
        elapsed = time.time() - start
        return {
            "return_code": proc.returncode,
            "elapsed_seconds": elapsed,
            "stdout_tail": (proc.stdout or "")[-4000:],
            "stderr_tail": (proc.stderr or "")[-4000:],
            "timed_out": False,
            "exception": None,
        }
    except subprocess.TimeoutExpired as e:
        elapsed = time.time() - start
        return {
            "return_code": 124,
            "elapsed_seconds": elapsed,
            "stdout_tail": (e.stdout or "")[-4000:] if isinstance(e.stdout, str) else "",
            "stderr_tail": (e.stderr or "")[-4000:] if isinstance(e.stderr, str) else "",
            "timed_out": True,
            "exception": "TimeoutExpired",
        }
    except Exception as e:
        elapsed = time.time() - start
        return {
            "return_code": 125,
            "elapsed_seconds": elapsed,
            "stdout_tail": "",
            "stderr_tail": str(e),
            "timed_out": False,
            "exception": type(e).__name__,
        }


def render_template_to_argv(template: str, values: Dict[str, Any]) -> List[str]:
    return shlex.split(template.format(**{k: str(v) for k, v in values.items()}))


class LockFile:
    def __init__(self, path: Path):
        self.path = path

    def acquire(self) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        try:
            fd = os.open(str(self.path), os.O_CREAT | os.O_EXCL | os.O_WRONLY)
            with os.fdopen(fd, "w", encoding="utf-8") as f:
                f.write(f"pid={os.getpid()}\ncreated_at={utc_now_iso()}\n")
        except FileExistsError:
            raise RuntimeError(f"Lock exists: {self.path}. Confirm no worker is running before deleting it.")

    def release(self) -> None:
        try:
            self.path.unlink(missing_ok=True)
        except Exception:
            pass


class LineLogger:
    def __init__(self, path: Path):
        self.path = path
        self.path.parent.mkdir(parents=True, exist_ok=True)

    def write(self, message: str) -> None:
        line = f"[{dt.datetime.now().isoformat(timespec='seconds')}] {message}"
        print(line, flush=True)
        with self.path.open("a", encoding="utf-8") as f:
            f.write(line + "\n")


def append_csv(path: Path, row: Dict[str, Any], fieldnames: List[str]) -> None:
    ensure_parent(path)
    exists = path.exists()
    with path.open("a", encoding="utf-8", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        if not exists:
            writer.writeheader()
        writer.writerow({k: row.get(k, "") for k in fieldnames})
