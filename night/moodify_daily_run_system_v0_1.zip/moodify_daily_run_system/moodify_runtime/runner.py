from __future__ import annotations

import os
import time
from pathlib import Path
from typing import Any, Dict, List, Optional

from .config import RuntimeConfig
from .metrics import compare_before_after
from .queue import load_queue, rewrite_queue
from .utils import (
    LineLogger,
    LockFile,
    append_csv,
    local_stamp,
    quote_cmd,
    render_template_to_argv,
    run_command,
    utc_now_iso,
    write_json,
)


MANIFEST_FIELDS = [
    "run_id", "task_id", "sample_id", "input_path", "preset", "status",
    "return_code", "elapsed_seconds", "output_dir", "template_index",
    "pseudo_mrs_before", "pseudo_mrs_after", "pseudo_delta_mrs", "error"
]


def select_pending_tasks(queue_rows: List[Dict[str, Any]], limit: int = 0) -> List[Dict[str, Any]]:
    pending = [r for r in queue_rows if r.get("status") in ("pending", "retry")]
    pending.sort(key=lambda r: (int(r.get("priority", 5)), r.get("created_at") or ""))
    if limit and limit > 0:
        return pending[:limit]
    return pending


def replace_task(queue_rows: List[Dict[str, Any]], updated: Dict[str, Any]) -> List[Dict[str, Any]]:
    out = []
    for row in queue_rows:
        if row.get("task_id") == updated.get("task_id"):
            out.append(updated)
        else:
            out.append(row)
    return out


def run_daily(
    cfg: RuntimeConfig,
    limit: int = 0,
    dry_run: bool = False,
    run_id: Optional[str] = None,
) -> Dict[str, Any]:
    cfg = cfg.resolved()
    run_id = run_id or local_stamp()
    run_dir = cfg.output_root / run_id
    run_dir.mkdir(parents=True, exist_ok=True)

    logger = LineLogger(run_dir / "daily_run.log")
    lock = LockFile(cfg.output_root / "daily_run.lock")
    summary: Dict[str, Any] = {
        "run_id": run_id,
        "started_at": utc_now_iso(),
        "dry_run": dry_run,
        "run_dir": str(run_dir),
        "queue_path": str(cfg.queue_path),
        "success": 0,
        "failed": 0,
        "dry_run_tasks": 0,
        "total_selected": 0,
        "tasks": [],
    }

    try:
        lock.acquire()
        logger.write("Moodify Daily Run START")
        logger.write(f"project_root={cfg.project_root}")
        logger.write(f"queue_path={cfg.queue_path}")

        queue_rows = load_queue(cfg)
        tasks = select_pending_tasks(queue_rows, limit=limit)
        summary["total_selected"] = len(tasks)
        logger.write(f"selected_tasks={len(tasks)}")

        env = os.environ.copy()
        env.update({str(k): str(v) for k, v in cfg.env.items()})
        existing_pythonpath = env.get("PYTHONPATH", "")
        env["PYTHONPATH"] = str(cfg.project_root) + (os.pathsep + existing_pythonpath if existing_pythonpath else "")

        for task in tasks:
            task = dict(task)
            task["run_id"] = run_id
            task["started_at"] = utc_now_iso()
            task["attempts"] = int(task.get("attempts") or 0) + 1

            input_path = Path(task["input_path"])
            preset = task["preset"]
            sample_id = task["sample_id"]
            task_output_dir = run_dir / sample_id / preset
            task_output_dir.mkdir(parents=True, exist_ok=True)
            task["output_dir"] = str(task_output_dir)

            context = {
                "python": cfg.python,
                "project_root": cfg.project_root,
                "input": input_path,
                "output_dir": task_output_dir,
                "preset": preset,
                "sample_id": sample_id,
                "task_id": task["task_id"],
                "run_id": run_id,
            }

            if dry_run:
                logger.write(f"[DRY-RUN] task={task['task_id']} input={input_path} preset={preset}")
                for i, template in enumerate(cfg.command_templates):
                    try:
                        argv = render_template_to_argv(template, context)
                        logger.write(f"[DRY-RUN] template#{i}: {quote_cmd(argv)}")
                    except Exception as e:
                        logger.write(f"[DRY-RUN] template#{i} invalid: {e}")
                task["status"] = "pending"
                summary["dry_run_tasks"] += 1
                continue

            task_ok = False
            chosen_result: Optional[Dict[str, Any]] = None
            chosen_template_index: Optional[int] = None
            error = ""

            for i, template in enumerate(cfg.command_templates):
                try:
                    argv = render_template_to_argv(template, context)
                except Exception as e:
                    error = f"template_error: {e}"
                    logger.write(error)
                    continue

                logger.write(f"RUN task={task['task_id']} template={i} cmd={quote_cmd(argv)}")
                result = run_command(
                    argv,
                    cwd=cfg.project_root,
                    env=env,
                    timeout=cfg.timeout_seconds_per_task,
                )
                logger.write(f"RESULT code={result['return_code']} elapsed={result['elapsed_seconds']:.2f}s")
                if result.get("stdout_tail"):
                    logger.write("STDOUT tail:\n" + result["stdout_tail"].strip())
                if result.get("stderr_tail"):
                    logger.write("STDERR tail:\n" + result["stderr_tail"].strip())

                chosen_result = result
                chosen_template_index = i

                if result["return_code"] == 0:
                    task_ok = True
                    break
                error = result.get("stderr_tail") or result.get("stdout_tail") or f"return_code={result['return_code']}"

            metrics = compare_before_after(input_path, task_output_dir)
            write_json(task_output_dir / "metrics_before_after.json", metrics)

            if task_ok:
                task["status"] = "done"
                task["last_error"] = None
                summary["success"] += 1
            else:
                task["status"] = "failed"
                task["last_error"] = error[-1000:] if error else "unknown_error"
                summary["failed"] += 1

            task["finished_at"] = utc_now_iso()
            queue_rows = replace_task(queue_rows, task)
            rewrite_queue(cfg, queue_rows)

            manifest_row = {
                "run_id": run_id,
                "task_id": task["task_id"],
                "sample_id": sample_id,
                "input_path": str(input_path),
                "preset": preset,
                "status": task["status"],
                "return_code": "" if not chosen_result else chosen_result.get("return_code"),
                "elapsed_seconds": "" if not chosen_result else f"{chosen_result.get('elapsed_seconds', 0):.2f}",
                "output_dir": str(task_output_dir),
                "template_index": "" if chosen_template_index is None else chosen_template_index,
                "pseudo_mrs_before": metrics.get("pseudo_mrs_before"),
                "pseudo_mrs_after": metrics.get("pseudo_mrs_after"),
                "pseudo_delta_mrs": metrics.get("pseudo_delta_mrs"),
                "error": task.get("last_error") or "",
            }
            append_csv(run_dir / "manifest.csv", manifest_row, MANIFEST_FIELDS)
            summary["tasks"].append(manifest_row)

            time.sleep(cfg.sleep_seconds_between_tasks)

        summary["finished_at"] = utc_now_iso()
        write_json(run_dir / "summary.json", summary)
        logger.write(f"FINISH success={summary['success']} failed={summary['failed']} dry_run={summary['dry_run_tasks']}")
        return summary
    except Exception as e:
        summary["finished_at"] = utc_now_iso()
        summary["fatal_error"] = f"{type(e).__name__}: {e}"
        write_json(run_dir / "summary.json", summary)
        logger.write(f"FATAL {type(e).__name__}: {e}")
        return summary
    finally:
        lock.release()
