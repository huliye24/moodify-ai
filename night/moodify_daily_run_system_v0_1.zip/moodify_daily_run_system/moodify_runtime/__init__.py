"""
Moodify Daily Run System

外层 Runtime：
- 不侵入 Moodify v01 / legacy 核心代码
- 负责每日样本登记、运行队列、云端夜跑、指标记录、报告、工艺记忆
"""

__version__ = "0.1.0"
