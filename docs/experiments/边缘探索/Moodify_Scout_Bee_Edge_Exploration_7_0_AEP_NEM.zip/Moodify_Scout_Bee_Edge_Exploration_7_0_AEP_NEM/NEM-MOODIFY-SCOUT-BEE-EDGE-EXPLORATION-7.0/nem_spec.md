# NEM Specification: Moodify Scout Bee Edge Exploration System

## Purpose

本 NEM 提供 Moodify 的“侦察蜂边缘探索能力”。

它的任务不是直接交付产品，也不是替代 6.x 支线实验，而是负责发现可能带来非线性跃迁的边缘技术方向。

主线和支线通常是线性提升：

```text
Runtime 更稳
MRS 更快
Preset 更准
样本库更完整
```

侦察蜂负责非线性探索：

```text
频谱修复新算法
动态真实度新模型
quick_mrs 快速估算
人声真实度修复
真实空间声场重建
参考曲目对齐
```

## Scope

### In Scope

- 边缘技术侦察
- 1-3 天最小实验设计
- Scout Brief 生成
- Scout Report 生成
- Scout Score 评分
- 舞蹈信号提交
- Gate 判断
- 转化为 AEP / NEM / 支线 / 主线候选

### Out of Scope

- 不直接重构主线 Runtime
- 不直接替换 MRS 公式
- 不直接修改生产 preset
- 不无限期探索
- 不用主观兴奋代替证据
- 不把每个新想法都升级成正式工程任务

## Maturity Roadmap

- [x] BASIC (v0.1): 定义侦察蜂协议、6 个初始侦察 AEP、Gate 与评分表
- [ ] STABLE (v0.3): 形成每周侦察节奏、PoEW 记录、Scout Archive
- [ ] ADOPTED (v1.0): 与 Moodify 潮汐循环、支线 Gate、主线 Roadmap 打通

## Constituent AEPs

| AEP ID | Role | Status |
|---|---|---|
| AEP-SCOUT-001-SPECTRAL-REPAIR | 探索频谱修复与塑料感治理 | draft |
| AEP-SCOUT-002-DYNAMIC-REALITY | 探索动态真实度与生命感恢复 | draft |
| AEP-SCOUT-003-QUICK-MRS | 探索桌面端快速评分系统 | draft |
| AEP-SCOUT-004-VOCAL-REALITY | 探索 AI 人声真实度修复 | draft |
| AEP-SCOUT-005-SPATIAL-FIELD | 探索真实空间声场重建 | draft |
| AEP-SCOUT-006-REFERENCE-MATCHING | 探索参考曲目对齐与专业母带方向 | draft |

## Dependencies

| NEM ID | Capability Required | Version |
|---|---|---|
| NEM-MOODIFY-RUNTIME-STABILITY-6.1 | Runtime 稳定运行能力 | >=0.1 |
| NEM-MOODIFY-MRS-PERFORMANCE-6.2 | MRS profiling 与评分能力 | >=0.1 |
| NEM-MOODIFY-PRESET-VALIDATION-6.3 | Preset before/after 验证能力 | >=0.1 |
| NEM-MOODIFY-SAMPLE-LIBRARY-6.4 | 样本库覆盖与 metadata 能力 | >=0.1 |

## Core Principle

```text
侦察蜂发现方向
支线验证方向
主线吸收成果
```

## Scout Gate Outcomes

| Outcome | Meaning | Next Action |
|---|---|---|
| TRANSFER_TO_MAINLINE | 已足够成熟，可进入产品主线 | 创建主线 AEP |
| TRANSFER_TO_BRANCH | 有潜力但需要验证 | 创建 6.x / 8.x 支线 NEM |
| ARCHIVE | 有趣但现在不做 | 存入 Scout Archive |
| REJECT | 暂无价值或风险过高 | 记录失败原因 |
