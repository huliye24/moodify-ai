# Scout Gate Specification

## Gate Outcomes

| Outcome | Meaning | Next |
|---|---|---|
| TRANSFER_TO_MAINLINE | 结果成熟且低风险 | 创建主线 AEP |
| TRANSFER_TO_BRANCH | 有价值但需要系统验证 | 创建支线 NEM |
| ARCHIVE | 有趣但当前不做 | 存入 Scout Archive |
| REJECT | 低价值或风险过高 | 停止方向 |

## TRANSFER_TO_MAINLINE Criteria

- Directly improves Electron / Runtime / MRS / Preset experience.
- Low implementation risk.
- Has measurable evidence.
- Can be rolled back.

## TRANSFER_TO_BRANCH Criteria

- Has strong potential.
- Needs more samples or longer validation.
- Can be decomposed into multiple AEPs.
- Has possible moat value.

## ARCHIVE Criteria

- Interesting but not urgent.
- Evidence insufficient.
- Current resources not enough.
- May become relevant later.

## REJECT Criteria

- No measurable signal.
- Too costly.
- Too risky.
- Not aligned with Moodify.
