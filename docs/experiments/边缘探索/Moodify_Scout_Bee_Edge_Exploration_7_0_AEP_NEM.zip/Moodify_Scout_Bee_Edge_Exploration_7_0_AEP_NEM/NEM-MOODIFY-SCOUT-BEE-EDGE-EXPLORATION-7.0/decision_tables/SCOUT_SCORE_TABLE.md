# Scout Score Table

## Score Dimensions

| Dimension | Meaning | Score |
|---|---|---|
| Technical Potential | 是否可能带来技术代差 | 1-5 |
| Moat Value | 是否能形成长期护城河 | 1-5 |
| Mainline Relevance | 是否服务 Electron / Runtime / MRS / Preset | 1-5 |
| Implementation Difficulty | 当前实现难度 | 1-5 |
| Experiment Cost | 时间、算力、样本成本 | 1-5 |
| Risk | 是否干扰主线或造成架构风险 | 1-5 |

## Formula

```text
Scout Score = Potential × Moat × Relevance / (Difficulty + Cost + Risk)
```

## Interpretation

| Score | Meaning | Action |
|---:|---|---|
| >= 5.0 | 强侦察信号 | 转支线或主线 |
| 3.0 - 5.0 | 中等信号 | 继续小实验 |
| 1.5 - 3.0 | 弱信号 | 归档观察 |
| < 1.5 | 无信号 | 拒绝或暂停 |
