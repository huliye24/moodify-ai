# Scout Report Template

## Scout ID

## Direction

## Experiment Summary

## Evidence

## Metrics

## What Worked

## What Failed

## Scout Score

| Dimension | Score 1-5 | Notes |
|---|---:|---|
| Technical Potential | | |
| Moat Value | | |
| Mainline Relevance | | |
| Implementation Difficulty | | |
| Experiment Cost | | |
| Risk | | |

## Dance Signal

```text
STRONG_DANCE / WEAK_DANCE / NO_DANCE
```

## Gate Recommendation

```text
TRANSFER_TO_MAINLINE / TRANSFER_TO_BRANCH / ARCHIVE / REJECT
```

## Next Action
