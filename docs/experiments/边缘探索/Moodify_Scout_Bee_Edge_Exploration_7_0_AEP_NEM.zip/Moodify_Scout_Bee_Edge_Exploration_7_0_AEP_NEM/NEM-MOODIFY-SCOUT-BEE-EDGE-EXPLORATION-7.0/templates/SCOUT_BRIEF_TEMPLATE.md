# Scout Brief Template

## Scout ID

`AEP-SCOUT-XXX`

## Exploration Direction

这个方向是什么？

## Why It Matters

它可能解决 Moodify 的哪个核心问题？

## Hypothesis

当前假设是什么？

## Minimum Probe

1-3 天内能做的最小实验是什么？

## Required Resources

需要什么样本、代码、论文、云服务器或工具？

## Success Signal

什么结果说明值得继续？

## Failure Signal

什么结果说明应该停止？

## Possible Conversion

- [ ] Transfer to Mainline
- [ ] Transfer to Branch NEM
- [ ] Archive
- [ ] Reject
