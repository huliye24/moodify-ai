# Dance Signal Template

## Scout ID

## Direction

## Signal Strength

```text
STRONG_DANCE / MEDIUM_DANCE / WEAK_DANCE / NO_DANCE
```

## Why

## Evidence

## Suggested Swarm Allocation

```text
0 agents: archive
1 agent: continue observation
2-3 agents: create follow-up AEP
4+ agents: create NEM
```

## Gate Recommendation
