# Scout Bee to Branch Conversion

## 什么时候转支线？

当侦察蜂发现某个方向有明显价值，但还不适合直接进入主线时，应转为正式支线 NEM。

## 转支线条件

至少满足 3 条：

- 有可复现实验结果
- MRS 或其他指标出现正向变化
- 能解释 Moodify 当前核心问题
- 有明确工程路径
- 不会打断主线
- 有护城河潜力
- 可拆成 3 个以上 AEP

## 转化格式

```text
Scout AEP
  ↓
Scout Report
  ↓
Dance Signal
  ↓
Gate: TRANSFER_TO_BRANCH
  ↓
New NEM
  ↓
Multiple AEPs
```

## 示例

```text
AEP-SCOUT-001-SPECTRAL-REPAIR
  ↓
发现频谱修复可以显著降低 plastic 标签
  ↓
转化为 NEM-MOODIFY-SPECTRAL-REPAIR-8.1
```
