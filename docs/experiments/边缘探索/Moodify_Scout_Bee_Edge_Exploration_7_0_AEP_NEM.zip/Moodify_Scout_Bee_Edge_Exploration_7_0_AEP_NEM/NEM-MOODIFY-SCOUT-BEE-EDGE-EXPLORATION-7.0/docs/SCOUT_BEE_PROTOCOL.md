# Scout Bee Protocol

## 一句话定义

侦察蜂系统是 Moodify 的边缘技术雷达，用于发现可能带来非线性跃迁的新算法、新工艺、新指标、新产品路径和新理论方向。

## 三层增长系统

```text
主线：向上生长，负责产品交付
支线：向下扎根，负责技术底座
侦察蜂：向外探索，负责非线性跃迁
```

## 侦察蜂不是什么？

侦察蜂不是主线开发。
侦察蜂不是随便开脑洞。
侦察蜂不是无限期研究。
侦察蜂不是看到一个新技术就打断当前工程。

## 侦察蜂只做四件事

```text
1. 发现边缘方向
2. 做最小验证
3. 提交舞蹈信号
4. 接受 Gate 判断
```

## 工作流

```text
Edge Signal
  ↓
Scout Brief
  ↓
1-3 Day Probe
  ↓
Scout Report
  ↓
Dance Signal
  ↓
Scout Gate
  ↓
Transfer / Archive / Reject
```

## Scout Score

```text
Scout Score = Potential × Moat × Mainline Relevance / (Difficulty + Cost + Risk)
```

评分不追求数学严密，目的是防止“兴奋感”替代工程判断。

## 五条纪律

1. 每个侦察 AEP 最多只做 1-3 天小实验。
2. 没有证据就不能升级为正式支线。
3. 不能直接打断主线。
4. 所有探索必须留下 Scout Report。
5. 有价值才转 AEP / NEM；没有价值就归档或拒绝。
