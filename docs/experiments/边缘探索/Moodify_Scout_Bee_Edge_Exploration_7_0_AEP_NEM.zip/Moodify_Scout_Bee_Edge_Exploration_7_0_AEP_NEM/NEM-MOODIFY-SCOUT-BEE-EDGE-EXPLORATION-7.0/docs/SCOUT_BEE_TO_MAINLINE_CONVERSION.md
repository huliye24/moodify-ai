# Scout Bee to Mainline Conversion

## 什么时候转主线？

当侦察蜂结果已经足够成熟，且能直接提升 Electron / MVP / Runtime / 用户体验时，可以转入主线。

## 转主线条件

必须满足：

- 风险低
- 对主线目标直接有帮助
- 工程实现成本可控
- 不破坏当前 Runtime / MRS / Preset
- 有清晰 rollback 方法
- 已有 PoEW 证据

## 示例

```text
quick_mrs 原型
  ↓
30 秒内完成评分
  ↓
与 full_mrs 排名相关性较高
  ↓
转入 Electron 桌面端即时评分功能
```
