# Scout Archive

Store scout directions that are interesting but not ready.

## Archive Entry Format

```text
date:
scout_id:
direction:
why_archived:
when_to_revisit:
evidence:
```
