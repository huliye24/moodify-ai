# Scout Bee AEPs

## 初始 6 个侦察蜂 AEP

| AEP ID | Direction | Why |
|---|---|---|
| AEP-SCOUT-001-SPECTRAL-REPAIR | 频谱修复 | 直接对应塑料感、over_dark、over_bright |
| AEP-SCOUT-002-DYNAMIC-REALITY | 动态真实度 | AI 音乐生命感不足可能与动态塌陷有关 |
| AEP-SCOUT-003-QUICK-MRS | 快速评分 | Electron 桌面端需要更快反馈 |
| AEP-SCOUT-004-VOCAL-REALITY | 人声真实度 | 全球 AI 音乐中人声是核心需求 |
| AEP-SCOUT-005-SPATIAL-FIELD | 空间声场 | AI 音乐空间常像贴上去 |
| AEP-SCOUT-006-REFERENCE-MATCHING | 参考曲目对齐 | 可能打开专业母带与 B 端方向 |

## 执行原则

每个 Scout AEP 都应：

1. 只做 1-3 天最小实验。
2. 不直接打断主线。
3. 不直接修改生产代码。
4. 必须输出 Scout Report。
5. 必须进入 Gate 判断。
