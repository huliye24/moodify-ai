# AEP-SCOUT-003-QUICK-MRS-T01: Define Quick Features

## Description

选择 RMS、loudness、centroid、slope、air_band、crest_factor 等低成本特征。

## Instructions

1. Read the AEP objective in `agent_spec.md`.
2. Execute only this task's scope.
3. Save evidence in `outputs/`.
4. Record notes for final Scout Report.

## Expected Evidence

- Commands or reasoning used.
- Input samples or references.
- Output files or tables.
- Observed result.
