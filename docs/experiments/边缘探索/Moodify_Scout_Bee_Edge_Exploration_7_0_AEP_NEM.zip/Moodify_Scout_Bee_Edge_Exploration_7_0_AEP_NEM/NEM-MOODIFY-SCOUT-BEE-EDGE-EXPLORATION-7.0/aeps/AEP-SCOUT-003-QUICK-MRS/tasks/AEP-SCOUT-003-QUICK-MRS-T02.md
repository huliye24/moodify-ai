# AEP-SCOUT-003-QUICK-MRS-T02: Compute Quick Scores

## Description

对 10-30 个样本计算 quick_mrs 草案。

## Instructions

1. Read the AEP objective in `agent_spec.md`.
2. Execute only this task's scope.
3. Save evidence in `outputs/`.
4. Record notes for final Scout Report.

## Expected Evidence

- Commands or reasoning used.
- Input samples or references.
- Output files or tables.
- Observed result.
