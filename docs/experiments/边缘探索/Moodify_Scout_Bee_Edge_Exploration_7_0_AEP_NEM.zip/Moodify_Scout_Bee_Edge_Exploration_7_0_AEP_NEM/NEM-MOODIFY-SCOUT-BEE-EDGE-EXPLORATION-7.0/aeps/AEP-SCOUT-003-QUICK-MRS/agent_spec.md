# Agent Specification: Quick MRS Scout

## Context

Moodify 已经有主线与 6.x 支线。主线负责 Electron / MVP 交付，支线负责 Runtime、MRS、Preset、样本库等稳定验证。

本 AEP 是 7.x 侦察蜂边缘探索链的一部分，目标是用 1-3 天做最小验证，判断该边缘方向是否值得转入正式支线或主线。

## Objective

探索是否可以用少量低成本声学特征形成 quick_mrs，用于 Electron 桌面端即时反馈。

## Hypothesis

full_mrs 慢，但一组低成本特征可能与 full_mrs 排序保持足够相关，可作为产品级快速反馈。

## Constraints

- 不要直接修改生产主线。
- 不要破坏 Runtime、MRS 或现有 preset。
- 不要无限期探索。
- 不要只给主观判断。
- 必须输出可复盘证据。
- 必须给出 Gate 建议。

## Input Materials

- Moodify 当前样本库。
- Runtime 输出。
- MRS Open / MRS scoring 结果。
- Preset before/after 结果。
- 如需要，可使用少量候选音频样本做最小实验。

## Success Definition

quick_mrs 比 full_mrs 明显更快，且与 full_mrs 排序有可接受相关性。
