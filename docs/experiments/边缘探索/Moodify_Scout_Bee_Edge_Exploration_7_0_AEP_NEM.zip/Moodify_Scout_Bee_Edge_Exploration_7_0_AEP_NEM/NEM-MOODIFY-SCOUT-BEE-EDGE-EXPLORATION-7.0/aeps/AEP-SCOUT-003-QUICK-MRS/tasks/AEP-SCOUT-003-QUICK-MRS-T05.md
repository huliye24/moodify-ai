# AEP-SCOUT-003-QUICK-MRS-T05: Write Scout Report

## Description

判断是否转入 6.2 或 Electron 主线。

## Instructions

1. Read the AEP objective in `agent_spec.md`.
2. Execute only this task's scope.
3. Save evidence in `outputs/`.
4. Record notes for final Scout Report.

## Expected Evidence

- Commands or reasoning used.
- Input samples or references.
- Output files or tables.
- Observed result.
