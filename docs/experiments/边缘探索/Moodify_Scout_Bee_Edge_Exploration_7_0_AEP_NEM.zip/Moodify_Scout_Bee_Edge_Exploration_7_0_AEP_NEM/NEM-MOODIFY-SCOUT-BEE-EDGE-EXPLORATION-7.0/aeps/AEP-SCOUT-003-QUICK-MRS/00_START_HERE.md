# AEP-SCOUT-003-QUICK-MRS: 快速 MRS 侦察蜂

## For Humans

This AEP explores: **探索是否可以用少量低成本声学特征形成 quick_mrs，用于 Electron 桌面端即时反馈。**

## For AI Agents

1. Read `agent_spec.md`
2. Read `rules.md`
3. Follow `task_map.yaml`
4. Write outputs into `outputs/`
5. Write final report to `reports/final_report.md`
6. Check `validation/acceptance_criteria.md`
7. Produce a Scout Report and Dance Signal

## Quick Links

- [Agent Spec](agent_spec.md)
- [Human Brief](human_brief.md)
- [Task Map](task_map.yaml)
- [Rules](rules.md)
- [Acceptance Criteria](validation/acceptance_criteria.md)
