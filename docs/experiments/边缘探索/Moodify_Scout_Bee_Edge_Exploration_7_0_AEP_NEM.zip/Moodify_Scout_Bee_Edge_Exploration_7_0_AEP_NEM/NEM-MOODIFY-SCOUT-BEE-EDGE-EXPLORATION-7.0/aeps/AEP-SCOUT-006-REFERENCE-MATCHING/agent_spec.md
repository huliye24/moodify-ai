# Agent Specification: Reference Matching Scout

## Context

Moodify 已经有主线与 6.x 支线。主线负责 Electron / MVP 交付，支线负责 Runtime、MRS、Preset、样本库等稳定验证。

本 AEP 是 7.x 侦察蜂边缘探索链的一部分，目标是用 1-3 天做最小验证，判断该边缘方向是否值得转入正式支线或主线。

## Objective

探索 AI 音乐是否可以向真实发行曲目的频谱、动态、空间和响度结构靠近。

## Hypothesis

参考曲目对齐可以让 Moodify 从普通 preset 进入专业 mastering / B 端方向，但需要避免抄袭和过拟合。

## Constraints

- 不要直接修改生产主线。
- 不要破坏 Runtime、MRS 或现有 preset。
- 不要无限期探索。
- 不要只给主观判断。
- 必须输出可复盘证据。
- 必须给出 Gate 建议。

## Input Materials

- Moodify 当前样本库。
- Runtime 输出。
- MRS Open / MRS scoring 结果。
- Preset before/after 结果。
- 如需要，可使用少量候选音频样本做最小实验。

## Success Definition

能用统计特征解释 AI 音乐与真实发行质感差距，并提出安全工程路径。
