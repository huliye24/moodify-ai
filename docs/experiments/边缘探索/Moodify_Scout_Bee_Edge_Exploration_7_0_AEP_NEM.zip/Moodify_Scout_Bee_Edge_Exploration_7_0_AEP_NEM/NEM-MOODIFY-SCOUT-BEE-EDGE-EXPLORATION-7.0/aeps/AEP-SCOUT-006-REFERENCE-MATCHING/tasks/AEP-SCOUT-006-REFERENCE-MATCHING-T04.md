# AEP-SCOUT-006-REFERENCE-MATCHING-T04: Prototype Safe Matching

## Description

尝试只对统计特征做保守靠近，不复制旋律或素材。

## Instructions

1. Read the AEP objective in `agent_spec.md`.
2. Execute only this task's scope.
3. Save evidence in `outputs/`.
4. Record notes for final Scout Report.

## Expected Evidence

- Commands or reasoning used.
- Input samples or references.
- Output files or tables.
- Observed result.
