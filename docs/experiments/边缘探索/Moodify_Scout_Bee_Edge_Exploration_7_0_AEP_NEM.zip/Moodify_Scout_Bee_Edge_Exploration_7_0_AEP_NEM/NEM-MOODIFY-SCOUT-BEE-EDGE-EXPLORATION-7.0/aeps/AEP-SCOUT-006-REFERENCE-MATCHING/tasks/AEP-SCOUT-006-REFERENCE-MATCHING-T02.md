# AEP-SCOUT-006-REFERENCE-MATCHING-T02: Extract Reference Features

## Description

提取参考曲目的统计特征，不复制音频内容。

## Instructions

1. Read the AEP objective in `agent_spec.md`.
2. Execute only this task's scope.
3. Save evidence in `outputs/`.
4. Record notes for final Scout Report.

## Expected Evidence

- Commands or reasoning used.
- Input samples or references.
- Output files or tables.
- Observed result.
