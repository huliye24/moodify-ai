# AEP-SCOUT-006-REFERENCE-MATCHING-T01: Define Reference Criteria

## Description

定义参考曲目的选择标准，不使用受限内容作为训练数据。

## Instructions

1. Read the AEP objective in `agent_spec.md`.
2. Execute only this task's scope.
3. Save evidence in `outputs/`.
4. Record notes for final Scout Report.

## Expected Evidence

- Commands or reasoning used.
- Input samples or references.
- Output files or tables.
- Observed result.
