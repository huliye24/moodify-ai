# AEP-SCOUT-006-REFERENCE-MATCHING-T03: Compare AI vs Reference

## Description

计算 AI 样本与参考统计特征差距。

## Instructions

1. Read the AEP objective in `agent_spec.md`.
2. Execute only this task's scope.
3. Save evidence in `outputs/`.
4. Record notes for final Scout Report.

## Expected Evidence

- Commands or reasoning used.
- Input samples or references.
- Output files or tables.
- Observed result.
