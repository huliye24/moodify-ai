# AEP-SCOUT-004-VOCAL-REALITY-T03: Measure Vocal Features

## Description

提取人声相关频谱、中心稳定、齿音等候选特征。

## Instructions

1. Read the AEP objective in `agent_spec.md`.
2. Execute only this task's scope.
3. Save evidence in `outputs/`.
4. Record notes for final Scout Report.

## Expected Evidence

- Commands or reasoning used.
- Input samples or references.
- Output files or tables.
- Observed result.
