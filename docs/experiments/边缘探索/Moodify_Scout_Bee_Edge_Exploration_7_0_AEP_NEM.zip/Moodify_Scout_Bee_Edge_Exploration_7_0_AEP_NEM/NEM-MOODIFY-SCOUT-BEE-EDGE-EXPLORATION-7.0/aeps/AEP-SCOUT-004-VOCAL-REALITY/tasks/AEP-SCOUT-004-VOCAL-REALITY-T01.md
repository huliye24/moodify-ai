# AEP-SCOUT-004-VOCAL-REALITY-T01: Select Vocal Samples

## Description

选择 5-10 个中英法等多语言人声样本。

## Instructions

1. Read the AEP objective in `agent_spec.md`.
2. Execute only this task's scope.
3. Save evidence in `outputs/`.
4. Record notes for final Scout Report.

## Expected Evidence

- Commands or reasoning used.
- Input samples or references.
- Output files or tables.
- Observed result.
