# AEP-SCOUT-004-VOCAL-REALITY-T02: Tag Vocal Problems

## Description

标注 vocal_artifact、sibilance、thin、fake_emotion 等问题。

## Instructions

1. Read the AEP objective in `agent_spec.md`.
2. Execute only this task's scope.
3. Save evidence in `outputs/`.
4. Record notes for final Scout Report.

## Expected Evidence

- Commands or reasoning used.
- Input samples or references.
- Output files or tables.
- Observed result.
