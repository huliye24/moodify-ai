# AEP-SCOUT-004-VOCAL-REALITY-T04: Prototype Vocal Repair

## Description

尝试保守人声修复或只是指标检测。

## Instructions

1. Read the AEP objective in `agent_spec.md`.
2. Execute only this task's scope.
3. Save evidence in `outputs/`.
4. Record notes for final Scout Report.

## Expected Evidence

- Commands or reasoning used.
- Input samples or references.
- Output files or tables.
- Observed result.
