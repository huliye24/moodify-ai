# Changelog: AEP-SCOUT-004-VOCAL-REALITY

## v0.1.0 — 2026-06-03
- Initial scout AEP package created.
