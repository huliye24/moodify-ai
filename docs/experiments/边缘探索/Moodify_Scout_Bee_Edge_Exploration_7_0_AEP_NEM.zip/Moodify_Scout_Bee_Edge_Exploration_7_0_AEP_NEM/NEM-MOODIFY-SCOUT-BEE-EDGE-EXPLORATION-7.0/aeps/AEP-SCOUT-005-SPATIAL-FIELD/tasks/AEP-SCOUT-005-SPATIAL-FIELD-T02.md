# AEP-SCOUT-005-SPATIAL-FIELD-T02: Measure Spatial Features

## Description

计算 stereo_width、mid_side_ratio、reverb_tail proxy。

## Instructions

1. Read the AEP objective in `agent_spec.md`.
2. Execute only this task's scope.
3. Save evidence in `outputs/`.
4. Record notes for final Scout Report.

## Expected Evidence

- Commands or reasoning used.
- Input samples or references.
- Output files or tables.
- Observed result.
