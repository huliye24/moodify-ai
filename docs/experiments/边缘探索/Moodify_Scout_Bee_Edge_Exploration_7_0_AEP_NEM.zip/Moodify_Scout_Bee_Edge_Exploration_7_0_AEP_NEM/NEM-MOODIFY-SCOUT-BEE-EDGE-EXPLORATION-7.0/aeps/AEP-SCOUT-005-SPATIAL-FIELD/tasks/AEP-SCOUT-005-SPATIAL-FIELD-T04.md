# AEP-SCOUT-005-SPATIAL-FIELD-T04: Evaluate Center and Width

## Description

比较空间变化、MRS、中心稳定、OPR。

## Instructions

1. Read the AEP objective in `agent_spec.md`.
2. Execute only this task's scope.
3. Save evidence in `outputs/`.
4. Record notes for final Scout Report.

## Expected Evidence

- Commands or reasoning used.
- Input samples or references.
- Output files or tables.
- Observed result.
