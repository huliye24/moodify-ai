# AEP-SCOUT-005-SPATIAL-FIELD-T03: Prototype Spatial Repair

## Description

尝试中心保持、深度增强或空间收敛策略。

## Instructions

1. Read the AEP objective in `agent_spec.md`.
2. Execute only this task's scope.
3. Save evidence in `outputs/`.
4. Record notes for final Scout Report.

## Expected Evidence

- Commands or reasoning used.
- Input samples or references.
- Output files or tables.
- Observed result.
