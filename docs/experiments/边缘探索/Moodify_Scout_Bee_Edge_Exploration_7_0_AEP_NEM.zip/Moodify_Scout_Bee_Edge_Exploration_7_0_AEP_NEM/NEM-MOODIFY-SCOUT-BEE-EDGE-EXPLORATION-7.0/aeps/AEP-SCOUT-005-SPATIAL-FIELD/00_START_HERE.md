# AEP-SCOUT-005-SPATIAL-FIELD: 空间声场侦察蜂

## For Humans

This AEP explores: **探索 AI 音乐的空间感为什么像贴上去，以及是否可以建立更真实的空间声场处理方向。**

## For AI Agents

1. Read `agent_spec.md`
2. Read `rules.md`
3. Follow `task_map.yaml`
4. Write outputs into `outputs/`
5. Write final report to `reports/final_report.md`
6. Check `validation/acceptance_criteria.md`
7. Produce a Scout Report and Dance Signal

## Quick Links

- [Agent Spec](agent_spec.md)
- [Human Brief](human_brief.md)
- [Task Map](task_map.yaml)
- [Rules](rules.md)
- [Acceptance Criteria](validation/acceptance_criteria.md)
