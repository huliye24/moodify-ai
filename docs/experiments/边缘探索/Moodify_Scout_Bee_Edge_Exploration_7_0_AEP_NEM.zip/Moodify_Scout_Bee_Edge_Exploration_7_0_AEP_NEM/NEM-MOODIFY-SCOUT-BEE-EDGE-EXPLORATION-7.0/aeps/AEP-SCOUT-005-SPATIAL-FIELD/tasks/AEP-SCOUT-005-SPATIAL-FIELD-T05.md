# AEP-SCOUT-005-SPATIAL-FIELD-T05: Write Scout Report

## Description

判断是否转入风格空间 preset 支线。

## Instructions

1. Read the AEP objective in `agent_spec.md`.
2. Execute only this task's scope.
3. Save evidence in `outputs/`.
4. Record notes for final Scout Report.

## Expected Evidence

- Commands or reasoning used.
- Input samples or references.
- Output files or tables.
- Observed result.
