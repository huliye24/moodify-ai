# Changelog: AEP-SCOUT-005-SPATIAL-FIELD

## v0.1.0 — 2026-06-03
- Initial scout AEP package created.
