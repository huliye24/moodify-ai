# AEP-SCOUT-005-SPATIAL-FIELD-T01: Select Spatial Samples

## Description

选择 fake_space、wide_space 风险、人声中心被拉散的样本。

## Instructions

1. Read the AEP objective in `agent_spec.md`.
2. Execute only this task's scope.
3. Save evidence in `outputs/`.
4. Record notes for final Scout Report.

## Expected Evidence

- Commands or reasoning used.
- Input samples or references.
- Output files or tables.
- Observed result.
