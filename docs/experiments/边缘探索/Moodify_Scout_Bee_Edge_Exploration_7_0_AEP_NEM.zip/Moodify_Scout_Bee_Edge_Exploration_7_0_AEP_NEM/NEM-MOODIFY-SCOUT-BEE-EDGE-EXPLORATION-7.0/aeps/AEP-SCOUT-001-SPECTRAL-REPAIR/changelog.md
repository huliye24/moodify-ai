# Changelog: AEP-SCOUT-001-SPECTRAL-REPAIR

## v0.1.0 — 2026-06-03
- Initial scout AEP package created.
