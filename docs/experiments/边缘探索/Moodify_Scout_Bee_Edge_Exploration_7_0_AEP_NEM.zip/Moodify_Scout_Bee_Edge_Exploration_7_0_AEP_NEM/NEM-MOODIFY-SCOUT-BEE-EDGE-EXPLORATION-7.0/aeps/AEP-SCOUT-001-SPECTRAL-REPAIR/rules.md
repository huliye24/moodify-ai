# Execution Rules

## Must Do

- Use a small, bounded experiment.
- Record all assumptions.
- Produce before/after evidence where applicable.
- Write a Scout Report.
- Calculate Scout Score.
- Recommend one Gate outcome.

## Must NOT Do

- Do not modify production mainline code.
- Do not overwrite original audio samples.
- Do not rely only on subjective listening.
- Do not expand scope beyond 1-3 days.
- Do not claim adoption without evidence.

## If Stuck

- Reduce sample count.
- Simplify the prototype.
- Produce a negative Scout Report.
- Recommend ARCHIVE or REJECT.

## Stop Conditions

- Mainline disruption risk detected: stop and report.
- No measurable signal after minimum probe: archive or reject.
- Acceptance criteria failed: write failure report.
