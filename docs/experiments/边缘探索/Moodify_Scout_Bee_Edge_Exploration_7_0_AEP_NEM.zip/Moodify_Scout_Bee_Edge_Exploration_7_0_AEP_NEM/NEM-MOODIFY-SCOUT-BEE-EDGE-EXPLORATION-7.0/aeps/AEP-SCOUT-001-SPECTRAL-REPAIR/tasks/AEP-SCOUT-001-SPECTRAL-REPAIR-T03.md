# AEP-SCOUT-001-SPECTRAL-REPAIR-T03: Prototype Conservative Repair

## Description

设计一个不破坏动态的保守频谱修复脚本或 preset 草案。

## Instructions

1. Read the AEP objective in `agent_spec.md`.
2. Execute only this task's scope.
3. Save evidence in `outputs/`.
4. Record notes for final Scout Report.

## Expected Evidence

- Commands or reasoning used.
- Input samples or references.
- Output files or tables.
- Observed result.
