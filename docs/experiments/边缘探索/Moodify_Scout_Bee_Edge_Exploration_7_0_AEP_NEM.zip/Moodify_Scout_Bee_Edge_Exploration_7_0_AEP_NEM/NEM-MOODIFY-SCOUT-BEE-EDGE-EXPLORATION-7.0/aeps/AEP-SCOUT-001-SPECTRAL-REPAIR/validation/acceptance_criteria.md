# Acceptance Criteria

## Must Pass

- [ ] The experiment stayed within the scout scope.
- [ ] No production mainline files were modified without explicit approval.
- [ ] Evidence was saved in `outputs/`.
- [ ] A Scout Report was written.
- [ ] Scout Score was calculated.
- [ ] Gate recommendation was given.

## Should Pass

- [ ] At least 5 samples were inspected or tested.
- [ ] MRS or measurable audio features were used.
- [ ] Failure cases were recorded.

## Must Stop If

- [ ] The experiment requires a major runtime rewrite.
- [ ] The direction cannot be evaluated with available samples.
- [ ] The result depends only on subjective listening.
