# AEP-SCOUT-001-SPECTRAL-REPAIR-T02: Analyze Spectral Defects

## Description

对 before 样本提取 spectral centroid、air band、slope、band energy。

## Instructions

1. Read the AEP objective in `agent_spec.md`.
2. Execute only this task's scope.
3. Save evidence in `outputs/`.
4. Record notes for final Scout Report.

## Expected Evidence

- Commands or reasoning used.
- Input samples or references.
- Output files or tables.
- Observed result.
