# Agent Specification: Spectral Repair Scout

## Context

Moodify 已经有主线与 6.x 支线。主线负责 Electron / MVP 交付，支线负责 Runtime、MRS、Preset、样本库等稳定验证。

本 AEP 是 7.x 侦察蜂边缘探索链的一部分，目标是用 1-3 天做最小验证，判断该边缘方向是否值得转入正式支线或主线。

## Objective

探索 AI 音乐塑料感、过暗、过亮问题是否可以通过频谱修复或频谱重建得到改善。

## Hypothesis

AI 音乐的塑料感部分来自频谱能量分布异常、air band 不自然、spectral slope 过陡或高频结构虚假。通过保守频谱修复可能提升 MRS 或降低 problem tags。

## Constraints

- 不要直接修改生产主线。
- 不要破坏 Runtime、MRS 或现有 preset。
- 不要无限期探索。
- 不要只给主观判断。
- 必须输出可复盘证据。
- 必须给出 Gate 建议。

## Input Materials

- Moodify 当前样本库。
- Runtime 输出。
- MRS Open / MRS scoring 结果。
- Preset before/after 结果。
- 如需要，可使用少量候选音频样本做最小实验。

## Success Definition

至少 30% 样本出现 Delta_MRS 正向变化，且未引入新的 loudness cheat 或 dynamic damage。
