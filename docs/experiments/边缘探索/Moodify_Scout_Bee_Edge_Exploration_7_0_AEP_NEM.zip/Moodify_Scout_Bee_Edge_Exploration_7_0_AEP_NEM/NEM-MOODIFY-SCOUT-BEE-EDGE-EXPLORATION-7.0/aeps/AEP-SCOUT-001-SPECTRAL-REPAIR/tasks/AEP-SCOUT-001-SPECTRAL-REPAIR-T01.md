# AEP-SCOUT-001-SPECTRAL-REPAIR-T01: Collect Candidate Samples

## Description

选择 5-10 个 plastic / over_dark / over_bright 样本。

## Instructions

1. Read the AEP objective in `agent_spec.md`.
2. Execute only this task's scope.
3. Save evidence in `outputs/`.
4. Record notes for final Scout Report.

## Expected Evidence

- Commands or reasoning used.
- Input samples or references.
- Output files or tables.
- Observed result.
