# AEP-SCOUT-002-DYNAMIC-REALITY-T03: Prototype Dynamic Recovery

## Description

尝试保守动态恢复，不做响度作弊。

## Instructions

1. Read the AEP objective in `agent_spec.md`.
2. Execute only this task's scope.
3. Save evidence in `outputs/`.
4. Record notes for final Scout Report.

## Expected Evidence

- Commands or reasoning used.
- Input samples or references.
- Output files or tables.
- Observed result.
