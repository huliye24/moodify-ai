# AEP-SCOUT-002-DYNAMIC-REALITY-T02: Measure Dynamic Features

## Description

提取 dynamic_range、crest_factor、transient indicators。

## Instructions

1. Read the AEP objective in `agent_spec.md`.
2. Execute only this task's scope.
3. Save evidence in `outputs/`.
4. Record notes for final Scout Report.

## Expected Evidence

- Commands or reasoning used.
- Input samples or references.
- Output files or tables.
- Observed result.
