# AEP-SCOUT-002-DYNAMIC-REALITY: 动态真实度侦察蜂

## For Humans

This AEP explores: **探索 AI 音乐动态发软、瞬态不足、生命感不足是否可以通过动态恢复方向改善。**

## For AI Agents

1. Read `agent_spec.md`
2. Read `rules.md`
3. Follow `task_map.yaml`
4. Write outputs into `outputs/`
5. Write final report to `reports/final_report.md`
6. Check `validation/acceptance_criteria.md`
7. Produce a Scout Report and Dance Signal

## Quick Links

- [Agent Spec](agent_spec.md)
- [Human Brief](human_brief.md)
- [Task Map](task_map.yaml)
- [Rules](rules.md)
- [Acceptance Criteria](validation/acceptance_criteria.md)
