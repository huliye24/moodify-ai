# AEP-SCOUT-002-DYNAMIC-REALITY-T04: Evaluate Damage and Gain

## Description

比较动态指标、MRS、LoudnessPenalty、OPR。

## Instructions

1. Read the AEP objective in `agent_spec.md`.
2. Execute only this task's scope.
3. Save evidence in `outputs/`.
4. Record notes for final Scout Report.

## Expected Evidence

- Commands or reasoning used.
- Input samples or references.
- Output files or tables.
- Observed result.
