# Agent Specification: Dynamic Reality Scout

## Context

Moodify 已经有主线与 6.x 支线。主线负责 Electron / MVP 交付，支线负责 Runtime、MRS、Preset、样本库等稳定验证。

本 AEP 是 7.x 侦察蜂边缘探索链的一部分，目标是用 1-3 天做最小验证，判断该边缘方向是否值得转入正式支线或主线。

## Objective

探索 AI 音乐动态发软、瞬态不足、生命感不足是否可以通过动态恢复方向改善。

## Hypothesis

AI 音乐不真实的重要原因之一是动态范围、crest factor 和 transient structure 不自然。保守动态恢复可能提升 R_dynamic。

## Constraints

- 不要直接修改生产主线。
- 不要破坏 Runtime、MRS 或现有 preset。
- 不要无限期探索。
- 不要只给主观判断。
- 必须输出可复盘证据。
- 必须给出 Gate 建议。

## Input Materials

- Moodify 当前样本库。
- Runtime 输出。
- MRS Open / MRS scoring 结果。
- Preset before/after 结果。
- 如需要，可使用少量候选音频样本做最小实验。

## Success Definition

动态指标改善且 LoudnessPenalty 不恶化，至少部分样本 MRS 提升。
