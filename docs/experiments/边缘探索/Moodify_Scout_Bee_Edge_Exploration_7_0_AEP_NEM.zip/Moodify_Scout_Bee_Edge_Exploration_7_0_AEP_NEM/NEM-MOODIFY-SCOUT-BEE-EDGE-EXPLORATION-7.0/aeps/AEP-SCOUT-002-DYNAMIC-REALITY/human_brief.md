# Human Brief: 动态真实度侦察蜂

## Why this AEP?

这个侦察蜂方向可能为 Moodify 带来非线性提升。它不是主线交付任务，而是技术雷达任务。

## What will change?

如果验证成功，这个方向可以转化为正式支线 NEM，或被主线吸收为产品能力。

## Risks

- 分散主线注意力。
- 结果只停留在主观听感。
- 小样本结论过拟合。
- 新处理方式破坏 MRS、动态或真实度。
- 误把响度、亮度、宽度当作真实提升。

## Dependencies

- Runtime 基本稳定。
- MRS 可计算。
- 有少量代表样本。
- 能输出 before/after 对比。
