# Changelog: AEP-SCOUT-002-DYNAMIC-REALITY

## v0.1.0 — 2026-06-03
- Initial scout AEP package created.
