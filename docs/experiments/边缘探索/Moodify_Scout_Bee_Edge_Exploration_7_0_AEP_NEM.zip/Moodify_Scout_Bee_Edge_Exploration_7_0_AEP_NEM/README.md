# Moodify 侦察蜂边缘探索系统

## Package

`NEM-MOODIFY-SCOUT-BEE-EDGE-EXPLORATION-7.0`

## Purpose

这个压缩包把 Moodify 的“侦察蜂边缘探索系统”整理成符合 AEP-NEM 协议语义的 NEM 节点包。

它不是普通的想法清单，而是一套可执行、可验证、可归档、可转化的边缘技术探索系统。

## AEP-NEM 对齐

本包按 AEP-NEM 的六层概念组织：

| Layer | In This Package |
|---|---|
| AEP | 6 个侦察蜂探索原子包 |
| NEM | 一个可进化的侦察蜂边缘探索节点 |
| E-Chain | `ECHAIN-MOODIFY-SCOUT-BEE-7.x` |
| E-Organism | Moodify 工程生命体 |
| PoEW | 每次侦察实验的工程工作量证明 |
| Gate | 每个侦察方向是否转入支线/主线的判断闸门 |

## 包结构

```text
NEM-MOODIFY-SCOUT-BEE-EDGE-EXPLORATION-7.0/
├── nem_manifest.yaml
├── nem_spec.md
├── interface.yaml
├── evolution_log.md
├── aeps/
│   ├── README.md
│   ├── AEP-SCOUT-001-SPECTRAL-REPAIR/
│   ├── AEP-SCOUT-002-DYNAMIC-REALITY/
│   ├── AEP-SCOUT-003-QUICK-MRS/
│   ├── AEP-SCOUT-004-VOCAL-REALITY/
│   ├── AEP-SCOUT-005-SPATIAL-FIELD/
│   └── AEP-SCOUT-006-REFERENCE-MATCHING/
├── gates/
├── poew/
├── dependencies/
├── echain/
├── docs/
├── templates/
├── schemas/
├── decision_tables/
├── scout_archive/
└── reports/
```

## Core Idea

```text
主线 = 树干，负责产品交付
支线 = 树根，负责技术扎根
侦察蜂 = 蜂群探索，负责非线性跃迁
```

侦察蜂不能直接打断主线。它只负责：

```text
发现可能性
做最小验证
提交舞蹈信号
进入 Gate 判断
```

## Recommended Use

1. 先读 `nem_spec.md`
2. 再读 `docs/SCOUT_BEE_PROTOCOL.md`
3. 从 `aeps/README.md` 选择一个侦察蜂 AEP
4. 执行对应 AEP 的 `00_START_HERE.md`
5. 输出 Scout Report 与 PoEW
6. 通过 Gate 判断：转主线、转支线、归档或拒绝

## Created

2026-06-03T07:00:49.204746+00:00
