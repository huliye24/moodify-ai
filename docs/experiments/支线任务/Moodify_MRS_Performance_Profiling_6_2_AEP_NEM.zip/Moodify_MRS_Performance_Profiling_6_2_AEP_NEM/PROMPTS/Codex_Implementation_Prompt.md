# Codex 实现 Prompt：Moodify 6.2 MRS Profiling Instrumentation

请为 Moodify 项目实现 MRS 性能画像所需的最小代码改造。

## 目标

在不改变 MRS 公式输出结果的前提下，为 MRS 增加 profiling instrumentation。

---

## 需要实现

1. MRS 分阶段计时器。
2. 每个样本输出 profiling JSON。
3. 汇总 profiling CSV。
4. summary 中增加 MRS 性能字段。
5. 支持未来 scoring 参数：
   - none
   - quick_mrs
   - full_mrs
6. 保证没有 MRS 时 Runtime summary 不崩溃。
7. 尽量保持向后兼容。

---

## 建议字段

```json
{
  "sample_id": "",
  "file_name": "",
  "input_size_mb": 0,
  "duration_sec": 0,
  "sample_rate": 0,
  "channels": 0,
  "decoded_wav_size_mb": 0,
  "mrs_total_time_sec": 0,
  "load_time_sec": 0,
  "decode_time_sec": 0,
  "wav_write_time_sec": 0,
  "feature_extract_time_sec": 0,
  "submetric_time_sec": 0,
  "aggregation_time_sec": 0,
  "report_write_time_sec": 0,
  "cache_hit": false,
  "exit_code": 0,
  "error_type": null
}
```

---

## 不要做的事

```text
不要改 MRS 评分公式
不要改 preset 音频处理算法
不要删除原有报告字段
不要让 profiling 影响原评分结果
不要强制启用并行
```

---

## 输出要求

请提交：

```text
新增或修改的文件列表
关键代码说明
如何运行 profiling
如何查看结果
已知风险
```
