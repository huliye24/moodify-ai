# Claude 执行 Prompt：Moodify 6.2 MRS 性能画像实验

请在 Moodify 项目中执行 6.2 MRS 性能画像实验。

## 实验目标

解释 MRS 为什么会出现 1-6 分钟/文件的耗时，并设计可优化路径。

请不要修改 MRS 公式本身，本轮任务只做 profiling、瓶颈定位和优化建议。

---

## 需要回答的问题

```text
MRS 为什么 1-6 分钟/文件？
不同文件大小对耗时有什么影响？
WAV 中间文件大小对耗时有什么影响？
是否可以缓存特征？
是否可以并行评分？
是否可以把 MRS 设置为可选列？
是否需要 quick_mrs / full_mrs 两档？
```

---

## 执行步骤

1. 定位当前 MRS 评分入口。
2. 为 MRS 增加分阶段计时。
3. 至少记录：
   - 音频读取时间
   - 解码时间
   - WAV 中间文件生成时间
   - 特征提取时间
   - 子指标计算时间
   - 总分聚合时间
   - 报告写入时间
4. 选取 10-30 个真实 AI 音乐样本。
5. 对每个样本记录：
   - 文件大小
   - 时长
   - 采样率
   - 声道数
   - WAV 中间文件大小
   - MRS 总耗时
   - 各阶段耗时
6. 分析文件大小、时长、WAV 大小与耗时之间的关系。
7. 检查 MRS 是否存在重复特征计算。
8. 判断 feature cache 是否可行。
9. 判断文件级并行、preset 级并行、子指标级并行是否可行。
10. 设计 scoring=none / quick_mrs / full_mrs 策略。
11. 输出完整报告。

---

## 输出路径建议

```text
outputs/mrs_performance_6_2/
logs/mrs_performance_6_2/
reports/mrs_performance_6_2_report.md
```

---

## 最终报告必须包含

```text
实验摘要
样本列表
profiling 数据表
耗时阶段分解
文件大小影响分析
WAV 中间文件影响分析
缓存可行性分析
并行可行性分析
MRS 可选列设计
quick_mrs / full_mrs 建议
性能优化路线图
Gate：ADOPT / HOLD / REJECT
```

---

## 注意

不要只给主观结论。必须给出可复盘的数据表和日志路径。
