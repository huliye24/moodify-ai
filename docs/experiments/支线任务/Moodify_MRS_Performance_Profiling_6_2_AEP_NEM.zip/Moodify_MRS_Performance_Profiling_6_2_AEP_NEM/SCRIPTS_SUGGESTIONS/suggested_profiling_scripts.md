# Suggested Profiling Scripts

以下脚本名称只是建议，不要求一次性全部实现。

## 1. MRS profiling runner

```text
scripts/run_mrs_profiling_6_2.py
```

用途：

```text
批量运行 MRS profiling
输出 per-sample JSON
输出 summary CSV
```

## 2. MRS profiling analyzer

```text
scripts/analyze_mrs_profiling_6_2.py
```

用途：

```text
读取 profiling CSV
分析耗时阶段占比
分析文件大小/时长/WAV 大小关系
输出 Markdown 报告片段
```

## 3. Feature cache inspector

```text
scripts/inspect_mrs_feature_reuse.py
```

用途：

```text
扫描 MRS 子指标
识别重复计算的特征
提出可缓存字段
```

## 4. Parallel scoring simulator

```text
scripts/simulate_mrs_parallel_scoring.py
```

用途：

```text
对比串行/并行耗时
检查并行是否造成日志或输出冲突
```

## 5. quick_mrs prototype

```text
scripts/prototype_quick_mrs.py
```

用途：

```text
用低成本特征生成 quick_mrs
与 full_mrs 对比排序相关性
```
