# AEP-6.2-006：Optional MRS Column

## 名称

MRS 可选列策略设计

## 目标

判断：

> Runtime 是否应该允许关闭 MRS，或者把 MRS 作为可选评分列？

## 背景

在不同使用场景下，MRS 的必要性不同。

例如：

```text
用户只想快速导出音频 → 不一定需要 MRS
实验系统需要排序 → 需要 MRS
潮汐循环需要反馈 → 需要 MRS
Electron 桌面端即时预览 → 可能只需要 quick_mrs
Benchmark 报告 → 需要 full_mrs
```

## 建议配置

```text
--scoring none
--scoring quick_mrs
--scoring full_mrs
```

或配置文件：

```json
{
  "scoring": {
    "enabled": true,
    "mode": "quick_mrs"
  }
}
```

## 实验步骤

1. 检查当前 Runtime 是否强制执行 MRS。
2. 设计 scoring 参数。
3. 测试 scoring=none 是否可正常处理。
4. 测试 scoring=quick_mrs 是否可输出快速分。
5. 测试 scoring=full_mrs 是否保持完整报告。
6. 检查 summary 是否能兼容缺失 MRS 列。

## 判断标准

| 状态 | 标准 |
|---|---|
| ADOPT | MRS 可作为可选列接入 Runtime |
| HOLD | 设计清楚，但代码需要改造 |
| REJECT | 当前架构强绑定 MRS，无法拆分 |

---

## 输出要求

每个 AEP 完成后必须输出：

```text
实验结论
关键数据
发现的问题
建议修改
是否进入下一 AEP
Gate 状态：ADOPT / HOLD / REJECT
```

禁止只给主观判断，必须给出可复盘数据。
