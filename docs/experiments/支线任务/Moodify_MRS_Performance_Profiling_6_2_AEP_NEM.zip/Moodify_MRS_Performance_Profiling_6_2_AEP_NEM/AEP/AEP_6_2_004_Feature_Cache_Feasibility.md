# AEP-6.2-004：Feature Cache Feasibility

## 名称

MRS 特征缓存可行性实验

## 目标

判断：

> MRS 是否可以通过缓存特征减少重复计算？

## 可缓存对象

候选缓存包括：

```text
音频 hash
duration
sample_rate
rms
loudness
spectral_centroid
spectral_rolloff
spectral_bandwidth
spectral_slope
crest_factor
transient_features
dynamic_range
air_band_energy
texture_features
```

## 实验步骤

1. 梳理 MRS 当前计算的所有特征。
2. 标记哪些特征是多个子指标重复使用的。
3. 为每个音频建立 feature_cache key。
4. 设计缓存命中 / 未命中记录。
5. 对比启用缓存前后的耗时。
6. 判断缓存是否会影响 MRS 结果一致性。

## 缓存 key 建议

```text
cache_key = sha256(file_bytes + mrs_version + feature_config_version)
```

## 判断标准

| 状态 | 标准 |
|---|---|
| ADOPT | 缓存可减少明显重复计算，且结果一致 |
| HOLD | 缓存有价值，但需要重构代码 |
| REJECT | 缓存收益低或会污染结果 |

---

## 输出要求

每个 AEP 完成后必须输出：

```text
实验结论
关键数据
发现的问题
建议修改
是否进入下一 AEP
Gate 状态：ADOPT / HOLD / REJECT
```

禁止只给主观判断，必须给出可复盘数据。
