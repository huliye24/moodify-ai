# AEP-6.2-002：File Size Impact

## 名称

文件大小与音频时长对 MRS 耗时的影响

## 目标

分析：

> 文件大小、音频时长、采样率、声道数是否与 MRS 耗时强相关？

## 输入

使用 AEP-6.2-001 的 profiling 数据，并补充：

```text
input_size_mb
duration_sec
sample_rate
channels
bit_depth
input_format
```

## 实验步骤

1. 统计每个样本的文件大小。
2. 统计每个样本的音频时长。
3. 统计采样率和声道数。
4. 计算这些变量与 MRS 总耗时的关系。
5. 找出耗时异常样本。
6. 判断主要影响因素是文件大小、时长，还是处理流程本身。

## 建议分析

```text
duration_sec vs mrs_total_time_sec
input_size_mb vs mrs_total_time_sec
sample_rate vs mrs_total_time_sec
channels vs mrs_total_time_sec
```

## 判断标准

| 状态 | 标准 |
|---|---|
| ADOPT | 明确文件大小/时长对耗时的影响关系 |
| HOLD | 有初步关系，但样本不足 |
| REJECT | 数据无法支持判断 |

---

## 输出要求

每个 AEP 完成后必须输出：

```text
实验结论
关键数据
发现的问题
建议修改
是否进入下一 AEP
Gate 状态：ADOPT / HOLD / REJECT
```

禁止只给主观判断，必须给出可复盘数据。
