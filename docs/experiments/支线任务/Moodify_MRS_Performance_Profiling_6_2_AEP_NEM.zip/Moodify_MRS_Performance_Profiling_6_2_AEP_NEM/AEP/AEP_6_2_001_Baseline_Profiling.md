# AEP-6.2-001：Baseline Profiling

## 名称

MRS 当前耗时基线画像

## 目标

建立 MRS 当前版本的性能基线，回答：

> MRS 现在到底慢到什么程度？每个阶段分别耗时多少？

## 输入

建议使用：

```text
10-30 个真实 AI 音乐样本
每个样本至少跑 1 次 full_mrs
尽量覆盖不同长度、不同大小、不同风格
```

## 实验步骤

1. 找到当前 MRS 评分入口。
2. 在 MRS 评分流程中加入分阶段计时。
3. 至少记录以下阶段：
   - 文件读取
   - 音频解码
   - WAV 中间文件生成
   - 特征提取
   - 子指标计算
   - 总分聚合
   - 报告写入
4. 输出每个样本的耗时明细。
5. 生成汇总表。

## 关键指标

```text
mrs_total_time_sec
load_time_sec
decode_time_sec
wav_write_time_sec
feature_extract_time_sec
submetric_time_sec
aggregation_time_sec
report_write_time_sec
```

## 判断标准

| 状态 | 标准 |
|---|---|
| ADOPT | 已明确 MRS 主要耗时阶段 |
| HOLD | 有总耗时，但阶段拆分不完整 |
| REJECT | 无法解释 MRS 慢在哪里 |

---

## 输出要求

每个 AEP 完成后必须输出：

```text
实验结论
关键数据
发现的问题
建议修改
是否进入下一 AEP
Gate 状态：ADOPT / HOLD / REJECT
```

禁止只给主观判断，必须给出可复盘数据。
