# AEP-6.2-005：Parallel Scoring Feasibility

## 名称

MRS 并行评分可行性实验

## 目标

判断：

> MRS 是否可以通过并行评分提升吞吐量？

## 并行层级

可以测试三种并行方式：

```text
文件级并行：多个音频同时评分
preset 级并行：同一音频多个 preset 输出同时评分
子指标级并行：同一文件内多个 MRS 子指标并行计算
```

## 实验步骤

1. 测试串行评分基线。
2. 测试文件级并行。
3. 测试 preset 级并行。
4. 如有必要，测试子指标级并行。
5. 记录 CPU、内存、I/O 占用。
6. 检查日志是否混乱。
7. 检查输出结果是否一致。

## 关键指标

```text
serial_total_time_sec
parallel_total_time_sec
speedup_ratio
cpu_usage_avg
memory_peak_mb
io_wait
error_count
result_consistency
```

## 风险

```text
并行过度导致内存耗尽
I/O 竞争导致速度反而下降
日志混乱
缓存写入冲突
结果文件覆盖
```

## 判断标准

| 状态 | 标准 |
|---|---|
| ADOPT | 并行能稳定提升吞吐且不破坏结果 |
| HOLD | 并行有收益，但需要队列/锁/限流 |
| REJECT | 并行导致不稳定或收益很低 |

---

## 输出要求

每个 AEP 完成后必须输出：

```text
实验结论
关键数据
发现的问题
建议修改
是否进入下一 AEP
Gate 状态：ADOPT / HOLD / REJECT
```

禁止只给主观判断，必须给出可复盘数据。
