# AEP-6.2-007：quick_mrs / full_mrs 两档评分设计

## 名称

MRS 快慢两档评分体系

## 目标

判断：

> 是否需要将 MRS 拆成 quick_mrs 与 full_mrs 两档？

## 设计原则

```text
quick_mrs：快、粗略、用于交互体验
full_mrs：慢、完整、用于实验与标准报告
```

## quick_mrs 候选特征

quick_mrs 可以优先使用低成本特征：

```text
duration
sample_rate
rms
loudness
spectral_centroid
spectral_slope
air_band_energy
dynamic_range
crest_factor
```

目标耗时：

```text
单文件 5-30 秒内完成
```

## full_mrs 特征

full_mrs 保留完整 MRS Open v0.3.1 或后续版本：

```text
完整频谱真实度
过暗惩罚
HQ damage sensitivity
动态/空间/质感/情绪相关维度
完整报告
```

目标用途：

```text
潮汐循环
Benchmark
论文/实验
preset gate
B 端质量报告
```

## 实验步骤

1. 设计 quick_mrs 最小特征集合。
2. 对同一批样本计算 quick_mrs 与 full_mrs。
3. 对比两者排序相关性。
4. 统计 quick_mrs 耗时优势。
5. 判断 quick_mrs 是否足够用于桌面端即时反馈。

## 关键指标

```text
quick_mrs_time_sec
full_mrs_time_sec
speedup_ratio
spearman_quick_vs_full
top_k_consistency
bad_sample_detection_rate
```

## 判断标准

| 状态 | 标准 |
|---|---|
| ADOPT | quick_mrs 显著更快，且与 full_mrs 排序基本一致 |
| HOLD | quick_mrs 有速度优势，但准确性需校准 |
| REJECT | quick_mrs 太粗糙，不能用于产品反馈 |

---

## 输出要求

每个 AEP 完成后必须输出：

```text
实验结论
关键数据
发现的问题
建议修改
是否进入下一 AEP
Gate 状态：ADOPT / HOLD / REJECT
```

禁止只给主观判断，必须给出可复盘数据。
