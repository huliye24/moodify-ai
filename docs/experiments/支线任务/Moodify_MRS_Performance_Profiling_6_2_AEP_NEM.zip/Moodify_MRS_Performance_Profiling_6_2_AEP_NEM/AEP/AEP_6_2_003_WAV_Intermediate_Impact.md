# AEP-6.2-003：WAV Intermediate Impact

## 名称

WAV 中间文件大小对 MRS 耗时的影响

## 目标

分析：

> MRS 慢是否与中间 WAV 文件过大、重复生成、重复读取有关？

## 背景

Moodify 的处理流程中可能存在解码、转 WAV、中间文件写入和再次读取。对于长音频或高采样率音频，中间 WAV 文件可能显著放大 I/O 压力。

## 实验步骤

1. 记录每个任务生成的中间 WAV 文件大小。
2. 记录 WAV 生成耗时。
3. 记录 WAV 读取耗时。
4. 检查是否存在重复生成同一中间文件。
5. 检查是否可以使用内存对象替代部分磁盘 I/O。
6. 对比原文件大小与 WAV 文件大小。

## 关键指标

```text
input_size_mb
decoded_wav_size_mb
wav_expansion_ratio
wav_write_time_sec
wav_read_time_sec
mrs_total_time_sec
```

## 判断标准

| 状态 | 标准 |
|---|---|
| ADOPT | 明确 WAV 中间文件是否为主要瓶颈 |
| HOLD | 发现 I/O 可疑，但需要进一步验证 |
| REJECT | 无法获得中间文件数据 |

---

## 输出要求

每个 AEP 完成后必须输出：

```text
实验结论
关键数据
发现的问题
建议修改
是否进入下一 AEP
Gate 状态：ADOPT / HOLD / REJECT
```

禁止只给主观判断，必须给出可复盘数据。
