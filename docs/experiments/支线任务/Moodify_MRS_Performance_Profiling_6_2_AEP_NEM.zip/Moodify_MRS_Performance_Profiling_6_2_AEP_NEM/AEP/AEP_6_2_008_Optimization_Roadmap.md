# AEP-6.2-008：Optimization Roadmap

## 名称

MRS 性能优化路线图

## 目标

将 6.2 前 7 个 AEP 的实验结果整理成工程路线图。

## 输出内容

最终路线图必须包括：

```text
当前主要瓶颈
短期优化
中期优化
长期优化
风险项
需要新增的工程任务
是否进入 6.3 MRS 性能优化实验
```

## 短期优化候选

```text
增加 profiling 日志
避免重复生成 WAV
MRS 作为可选列
summary 兼容无 MRS 模式
增加 timeout
记录异常耗时样本
```

## 中期优化候选

```text
feature cache
quick_mrs / full_mrs 双模式
文件级并行评分
样本级缓存
Runtime scoring 参数标准化
```

## 长期优化候选

```text
MRS 计算内核重构
NumPy / SciPy 向量化
多进程评分池
本地桌面端 quick_mrs
云端 full_mrs
Benchmark 服务化
```

## 判断标准

| 状态 | 标准 |
|---|---|
| ADOPT | 已形成清晰可执行优化路线 |
| HOLD | 有方向，但需要补充数据 |
| REJECT | 无法从数据推出优化路径 |

---

## 输出要求

每个 AEP 完成后必须输出：

```text
实验结论
关键数据
发现的问题
建议修改
是否进入下一 AEP
Gate 状态：ADOPT / HOLD / REJECT
```

禁止只给主观判断，必须给出可复盘数据。
