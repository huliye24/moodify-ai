# Moodify 6.2 MRS 性能画像执行检查清单

## 开始前

- [ ] 确认当前 MRS 版本
- [ ] 确认 Runtime 版本
- [ ] 确认样本目录
- [ ] 确认输出目录
- [ ] 确认日志目录
- [ ] 确认不会修改 MRS 公式

## AEP-001 Baseline Profiling

- [ ] 已加入分阶段计时
- [ ] 已输出 profiling JSON
- [ ] 已输出 profiling CSV
- [ ] 已获得总耗时统计

## AEP-002 File Size Impact

- [ ] 已记录文件大小
- [ ] 已记录音频时长
- [ ] 已记录采样率
- [ ] 已记录声道数
- [ ] 已分析与耗时的关系

## AEP-003 WAV Intermediate Impact

- [ ] 已记录 WAV 中间文件大小
- [ ] 已记录 WAV 写入耗时
- [ ] 已分析 WAV 膨胀比例
- [ ] 已判断 I/O 是否为瓶颈

## AEP-004 Feature Cache

- [ ] 已列出可缓存特征
- [ ] 已识别重复计算
- [ ] 已设计 cache key
- [ ] 已判断缓存收益

## AEP-005 Parallel Scoring

- [ ] 已分析文件级并行
- [ ] 已分析 preset 级并行
- [ ] 已分析子指标级并行
- [ ] 已记录 CPU / 内存 / I/O 风险

## AEP-006 Optional MRS Column

- [ ] 已设计 scoring=none
- [ ] 已设计 scoring=quick_mrs
- [ ] 已设计 scoring=full_mrs
- [ ] 已检查 summary 兼容性

## AEP-007 quick_mrs / full_mrs

- [ ] 已定义 quick_mrs 特征
- [ ] 已定义 full_mrs 场景
- [ ] 已比较速度差异
- [ ] 已评估排序一致性

## AEP-008 Optimization Roadmap

- [ ] 已输出短期优化
- [ ] 已输出中期优化
- [ ] 已输出长期优化
- [ ] 已给出最终 Gate
