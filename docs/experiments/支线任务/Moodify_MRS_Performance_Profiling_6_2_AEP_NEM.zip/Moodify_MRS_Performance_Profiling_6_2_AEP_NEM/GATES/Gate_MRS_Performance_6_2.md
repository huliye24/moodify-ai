# Gate：MRS Performance Profiling 6.2

## Gate 名称

MRS 性能画像实验 Gate

## 目标

判断 6.2 是否完成了对 MRS 性能瓶颈的有效解释，并是否足以进入后续 6.3 MRS 性能优化实验。

---

## ADOPT 标准

满足以下条件，可判定为 ADOPT：

```text
已完成至少 10 个真实样本的 MRS profiling
已拆分 MRS 总耗时为多个阶段
已明确主要瓶颈阶段
已分析文件大小/时长与耗时关系
已分析 WAV 中间文件影响
已判断 feature cache 是否有价值
已判断并行评分是否有价值
已给出 MRS 可选列方案
已给出 quick_mrs / full_mrs 双档建议
已输出可执行优化路线图
```

ADOPT 意味着：

> 6.2 已经完成性能画像，可以进入 6.3 性能优化实验。

---

## HOLD 标准

出现以下情况，判定为 HOLD：

```text
profiling 数据存在，但样本数量不足
已发现瓶颈，但没有精确量化
缓存/并行方案有方向，但尚未验证
quick_mrs / full_mrs 只完成设计，未完成对比
MRS 可选列方案需要代码重构
```

HOLD 意味着：

> 6.2 有阶段性成果，但需要补充实验后再进入正式优化。

---

## REJECT 标准

出现以下情况，判定为 REJECT：

```text
无法获得 MRS 分阶段耗时
无法稳定复现实验
没有样本级数据
无法解释 1-6 分钟/文件的原因
无法判断缓存、并行、可选列是否有效
```

REJECT 意味着：

> 不能继续做 6.3 优化，必须先补 profiling 基础设施。

---

## 关键 Gate 指标

```text
sample_count
mrs_total_time_median
mrs_total_time_p90
main_bottleneck_stage
duration_time_correlation
file_size_time_correlation
wav_size_time_correlation
cache_expected_gain
parallel_expected_gain
quick_full_recommendation
optional_mrs_recommendation
```

---

## 最终 Gate 输出格式

```text
Gate Result: ADOPT / HOLD / REJECT

Reason:
- ...

Evidence:
- ...

Next:
- ...
```
