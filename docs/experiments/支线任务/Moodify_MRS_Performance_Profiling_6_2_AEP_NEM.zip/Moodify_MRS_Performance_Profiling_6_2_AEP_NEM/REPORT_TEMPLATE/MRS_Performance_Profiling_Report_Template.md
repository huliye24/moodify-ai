# Moodify 6.2 MRS 性能画像实验报告

## 1. 实验摘要

```text
实验名称：
实验时间：
项目根目录：
样本数量：
MRS 版本：
Runtime 版本：
最终 Gate：
```

---

## 2. 实验目标

本实验用于解释 MRS 为什么耗时较长，并设计性能优化路径。

核心问题：

```text
MRS 为什么 1-6 分钟/文件？
不同文件大小对耗时有什么影响？
WAV 中间文件大小对耗时有什么影响？
是否可以缓存特征？
是否可以并行评分？
是否可以把 MRS 设置为可选列？
是否需要 quick_mrs / full_mrs 两档？
```

---

## 3. 样本列表

| sample_id | file_name | duration_sec | input_size_mb | format | sample_rate | channels |
|---|---|---:|---:|---|---:|---:|
| | | | | | | |

---

## 4. Profiling 数据表

| sample_id | total | load | decode | wav_write | feature | submetric | aggregate | report |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
| | | | | | | | | |

---

## 5. 耗时阶段分解

### 主要瓶颈阶段

```text
主要瓶颈：
占比：
证据：
```

### 阶段占比

| 阶段 | 平均耗时 | 中位数 | P90 | 占比 |
|---|---:|---:|---:|---:|
| load | | | | |
| decode | | | | |
| wav_write | | | | |
| feature_extract | | | | |
| submetric | | | | |
| aggregation | | | | |
| report_write | | | | |

---

## 6. 文件大小影响分析

```text
input_size_mb 与 mrs_total_time_sec 的关系：
duration_sec 与 mrs_total_time_sec 的关系：
sample_rate 与 mrs_total_time_sec 的关系：
channels 与 mrs_total_time_sec 的关系：
```

结论：

```text
...
```

---

## 7. WAV 中间文件影响分析

```text
decoded_wav_size_mb：
wav_expansion_ratio：
wav_write_time_sec：
wav_read_time_sec：
```

结论：

```text
...
```

---

## 8. Feature Cache 可行性

```text
是否存在重复计算：
可缓存特征：
缓存 key 建议：
预计收益：
风险：
```

结论：

```text
建议 / 暂缓 / 不建议
```

---

## 9. 并行评分可行性

```text
文件级并行：
preset 级并行：
子指标级并行：
CPU 风险：
内存风险：
I/O 风险：
```

结论：

```text
建议 / 暂缓 / 不建议
```

---

## 10. MRS 可选列设计

建议配置：

```text
scoring=none
scoring=quick_mrs
scoring=full_mrs
```

Runtime 影响：

```text
...
```

Electron 桌面端影响：

```text
...
```

---

## 11. quick_mrs / full_mrs 两档设计

| 模式 | 用途 | 目标耗时 | 特征集合 | 适用场景 |
|---|---|---:|---|---|
| none | 只处理不评分 | 0 | 无 | 快速导出 |
| quick_mrs | 快速反馈 | 5-30s | 低成本特征 | 桌面端 |
| full_mrs | 完整报告 | 视情况 | 完整特征 | 实验/Benchmark |

---

## 12. 优化路线图

### 短期

```text
...
```

### 中期

```text
...
```

### 长期

```text
...
```

---

## 13. Gate 判断

```text
Gate Result: ADOPT / HOLD / REJECT
```

理由：

```text
...
```

证据：

```text
...
```

下一步：

```text
...
```
