# NEM-MRS-Performance-Profiling-6.2

# Moodify 支线计划 6.2：MRS 性能画像实验

## 一、节点定位

本节点是 Moodify 支线实验系统中的第二个 NEM 节点。

它的核心目标是解释：

> 为什么 MRS 会出现 1-6 分钟/文件的耗时？

并进一步设计：

> 如何让 MRS 从“研究型标准系统”逐步变成“产品级评分系统”。

MRS 对 Moodify 极其重要，因为它承担的是 AI 音乐真实度标准系统的角色。它不是普通指标，而是 Moodify 未来的跑分单位、排序单位、工艺验证单位和产品可信度基础。

但如果 MRS 性能过慢，会带来四个直接问题：

1. Runtime 吞吐量下降。
2. 24h 潮汐循环可处理样本数量下降。
3. Electron 桌面端用户等待时间过长。
4. 批量处理和 B 端业务难以扩展。

因此，6.2 不是要否定 MRS，而是要让 MRS 进入工程化优化阶段。

---

## 二、核心实验问题

本节点需要回答以下问题：

```text
MRS 为什么 1-6 分钟/文件？
不同文件大小对耗时有什么影响？
WAV 中间文件大小对耗时有什么影响？
是否可以缓存特征？
是否可以并行评分？
是否可以把 MRS 设置为可选列？
是否需要 quick_mrs / full_mrs 两档？
```

---

## 三、战略意义

MRS 是 Moodify 的标准系统。

如果 MRS 只停留在研究阶段，它可以慢一些；但如果 MRS 要进入 Runtime、桌面端、批量任务、B 端处理和未来 API，它必须具备可控性能。

因此，本节点的战略意义是：

> 让 MRS 从“可以算”进入“可以规模化算”。

更具体地说：

```text
MRS 公式可信
        ↓
MRS 性能可解释
        ↓
MRS 计算可优化
        ↓
MRS 可进入 Runtime
        ↓
MRS 可进入 Electron 桌面端
        ↓
MRS 成为 Moodify 的产品级标准单位
```

---

## 四、节点拆解

本 NEM 拆解为 8 个 AEP 工程原子包：

| AEP | 名称 | 目标 |
|---|---|---|
| AEP-6.2-001 | Baseline Profiling | 建立 MRS 当前耗时基线 |
| AEP-6.2-002 | File Size Impact | 分析文件大小/时长对耗时的影响 |
| AEP-6.2-003 | WAV Intermediate Impact | 分析中间 WAV 文件对耗时的影响 |
| AEP-6.2-004 | Feature Cache Feasibility | 判断是否可缓存特征 |
| AEP-6.2-005 | Parallel Scoring Feasibility | 判断是否可并行评分 |
| AEP-6.2-006 | Optional MRS Column | 设计 MRS 可选列策略 |
| AEP-6.2-007 | quick_mrs / full_mrs Tier | 设计快慢两档评分体系 |
| AEP-6.2-008 | Optimization Roadmap | 输出性能优化路线图 |

---

## 五、建议实验输入

建议选取 10-30 个真实 AI 音乐样本，覆盖以下区间：

| 类型 | 建议范围 |
|---|---|
| 短音频 | 30 秒 - 1 分钟 |
| 中等音频 | 2 - 4 分钟 |
| 长音频 | 5 - 8 分钟 |
| 小文件 | < 10 MB |
| 中等文件 | 10 - 50 MB |
| 大文件 | 50 - 200 MB |
| WAV 中间文件 | 记录解码后大小 |
| 不同 preset 输出 | clean_master / safe_air / warm_vocal / wide_space 等 |

---

## 六、核心指标

每个样本至少记录：

```text
sample_id
file_name
input_format
input_size_mb
duration_sec
sample_rate
channels
decoded_wav_size_mb
mrs_total_time_sec
load_time_sec
decode_time_sec
feature_extract_time_sec
submetric_time_sec
aggregation_time_sec
io_write_time_sec
cache_hit
cache_miss
cpu_usage_avg
memory_peak_mb
error_type
exit_code
```

---

## 七、关键判断

本节点最终需要形成以下判断：

### 1. MRS 慢在哪里？

可能瓶颈包括：

```text
音频解码
WAV 中间文件写入
librosa / scipy 特征提取
多维子指标重复计算
频谱计算重复执行
I/O 读写
Python 单线程执行
无缓存导致重复计算
过高采样率导致数据量膨胀
全曲计算而非片段抽样
```

---

### 2. MRS 是否可以缓存？

需要判断：

```text
同一 input 文件的基础特征是否可复用
同一 processed 文件的特征是否可复用
不同 MRS 版本之间哪些特征可复用
缓存 key 应该基于文件 hash 还是 sample_id
缓存失效策略如何设计
缓存是否会污染实验结果
```

---

### 3. MRS 是否可以并行？

需要判断：

```text
按文件并行是否安全
按子指标并行是否值得
CPU 核心是否足够
内存是否成为瓶颈
并行是否导致 I/O 冲突
并行是否影响日志完整性
```

---

### 4. MRS 是否应该可选？

建议形成三档策略：

```text
scoring = none
scoring = quick_mrs
scoring = full_mrs
```

其中：

```text
none：只处理音频，不跑分
quick_mrs：快速评分，用于桌面端即时反馈
full_mrs：完整评分，用于实验、报告、潮汐循环和 Benchmark
```

---

## 八、Gate 判断

最终 Gate 有三个状态：

```text
ADOPT：MRS 性能路径清晰，可进入 Runtime 优化
HOLD：瓶颈基本识别，但还需要更多数据
REJECT：性能画像数据不足，无法指导优化
```

详细标准见：

```text
GATES/Gate_MRS_Performance_6_2.md
```

---

## 九、推荐最终结论格式

```text
MRS 当前状态：HOLD / ADOPT / REJECT
主要瓶颈：
最相关变量：
是否引入缓存：
是否支持并行：
是否设置为可选列：
是否拆分 quick_mrs / full_mrs：
下一步工程任务：
```

---

## 十、与主线关系

本节点服务于 Moodify 主线：

```text
Electron 桌面端
Runtime 稳定运行
MRS 标准系统
批量处理体验
潮汐循环
B 端处理能力
```

如果 6.2 完成，后续可以进入：

```text
6.3 MRS 性能优化实验
6.4 Preset 工艺库稳定性实验
6.5 样本资产库标准化实验
6.6 报告与可解释性系统实验
```
