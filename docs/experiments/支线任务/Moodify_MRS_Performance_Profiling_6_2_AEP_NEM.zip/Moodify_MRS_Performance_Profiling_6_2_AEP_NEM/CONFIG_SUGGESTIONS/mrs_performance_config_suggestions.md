# MRS Performance Config Suggestions

## Runtime scoring 参数建议

建议 Runtime 逐步支持：

```json
{
  "scoring": {
    "enabled": true,
    "mode": "full_mrs",
    "timeout_sec": 600,
    "profile": true,
    "write_profile_json": true,
    "write_profile_csv": true
  }
}
```

## 三档评分模式

```text
none：不计算 MRS，只处理音频
quick_mrs：快速评分，用于桌面端即时反馈
full_mrs：完整评分，用于实验、Benchmark 和报告
```

## profiling 输出建议

```text
outputs/mrs_performance_6_2/profiles/{sample_id}.json
outputs/mrs_performance_6_2/profiling_summary.csv
reports/mrs_performance_6_2_report.md
```

## timeout 建议

```text
quick_mrs_timeout_sec = 60
full_mrs_timeout_sec = 600
batch_mrs_timeout_sec = 900
```

## 缓存建议

```json
{
  "feature_cache": {
    "enabled": false,
    "cache_dir": "data/mrs_feature_cache",
    "key": "sha256(file_bytes + mrs_version + feature_config_version)",
    "ttl_days": null
  }
}
```
