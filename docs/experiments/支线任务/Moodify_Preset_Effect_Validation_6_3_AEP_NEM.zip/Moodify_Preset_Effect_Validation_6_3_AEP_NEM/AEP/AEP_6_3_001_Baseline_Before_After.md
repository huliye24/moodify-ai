# AEP-6.3-001：Baseline Before/After

## 名称

Preset 前后对比基线实验

## 目标

建立每个样本在处理前后的基础数据表，确保后续所有 preset 判断都有统一基线。

## 输入

```text
20-50 首真实 AI 音乐样本
当前可用 preset 列表
当前 MRS 版本
```

## 实验步骤

1. 对每个原始样本计算 MRS_before。
2. 用每个 preset 处理样本。
3. 对处理后样本计算 MRS_after。
4. 计算 Delta_MRS。
5. 记录 LoudnessPenalty、OPR、动态、空间、频谱变化。
6. 输出 before/after 明细表。

## 关键指标

```text
sample_id
style_tag
preset_name
MRS_before
MRS_after
Delta_MRS
LoudnessPenalty_before
LoudnessPenalty_after
OPR_before
OPR_after
dynamic_change
space_change
spectrum_change
```

## 判断标准

| 状态 | 标准 |
|---|---|
| ADOPT | before/after 数据完整，可进入 preset 比较 |
| HOLD | 数据存在但样本或字段不足 |
| REJECT | 无法建立稳定 before/after 对比 |

---

## 输出要求

每个 AEP 完成后必须输出：

```text
实验结论
关键数据
发现的问题
建议修改
Preset Gate：ADOPT / HOLD / REJECT
是否进入下一 AEP
```

禁止只给主观听感判断，必须给出 before/after 数据。
