# AEP-6.3-002：Preset MRS Comparison

## 名称

Preset MRS 提升能力比较实验

## 目标

回答：

> 哪个 preset 能稳定提升 MRS？

## 实验步骤

1. 按 preset 聚合所有样本的 Delta_MRS。
2. 统计每个 preset 的平均 Delta_MRS。
3. 统计中位数 Delta_MRS。
4. 统计提升样本占比。
5. 统计恶化样本占比。
6. 识别极端恶化样本。
7. 输出 preset 排名表。

## 关键指标

```text
preset_name
mean_delta_mrs
median_delta_mrs
positive_rate
negative_rate
best_sample
worst_sample
p90_delta
p10_delta
```

## 判断标准

| 状态 | 标准 |
|---|---|
| ADOPT | 稳定正提升，且恶化率低 |
| HOLD | 平均提升但波动大，需要按风格拆分 |
| REJECT | 平均恶化或极端风险高 |

---

## 输出要求

每个 AEP 完成后必须输出：

```text
实验结论
关键数据
发现的问题
建议修改
Preset Gate：ADOPT / HOLD / REJECT
是否进入下一 AEP
```

禁止只给主观听感判断，必须给出 before/after 数据。
