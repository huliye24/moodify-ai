# AEP-6.3-004：Dynamic Damage Detection

## 名称

动态破坏检测实验

## 目标

回答：

> 哪个 preset 可能破坏动态？

## 背景

AI 音乐本身常有塑料感、瞬态软、层次不足的问题。若 preset 进一步压缩动态，可能会让音乐更假。

## 实验步骤

1. 记录 dynamic_range_before / after。
2. 记录 crest_factor_before / after。
3. 记录 transient 指标变化。
4. 分析 MRS 提升与动态下降是否同时出现。
5. 标记 dynamic_damage_flag。

## 关键指标

```text
dynamic_range_before
dynamic_range_after
dynamic_range_delta
crest_factor_before
crest_factor_after
crest_factor_delta
transient_change
dynamic_damage_flag
```

## 判断标准

| 状态 | 标准 |
|---|---|
| ADOPT | 能识别动态破坏型 preset |
| HOLD | 动态指标有变化，但阈值需校准 |
| REJECT | 无法判断动态损伤 |

---

## 输出要求

每个 AEP 完成后必须输出：

```text
实验结论
关键数据
发现的问题
建议修改
Preset Gate：ADOPT / HOLD / REJECT
是否进入下一 AEP
```

禁止只给主观听感判断，必须给出 before/after 数据。
