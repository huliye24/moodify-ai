# AEP-6.3-003：Loudness Cheat Detection

## 名称

响度作弊检测实验

## 目标

回答：

> 哪个 preset 只是通过变响制造提升假象？

## 背景

音乐处理很容易出现一种假象：

```text
声音更响
听起来更有冲击
短时间似乎更好
但动态、质感、真实度实际下降
```

Moodify 的 preset 不能依赖响度作弊。

## 实验步骤

1. 记录每个处理前后的 LUFS 或等效响度指标。
2. 记录 LoudnessPenalty 变化。
3. 记录动态范围变化。
4. 记录 crest factor 变化。
5. 判断 MRS 提升是否主要来自响度变化。
6. 标记 loudness_cheat_flag。

## 响度作弊判定候选

```text
Delta_MRS > 0
且 LoudnessPenalty_after 明显升高
且 dynamic_range_after 下降
且 crest_factor_after 下降
```

或：

```text
响度明显增加
但 OPR 变差
```

## 判断标准

| 状态 | 标准 |
|---|---|
| ADOPT | 能识别响度作弊 preset |
| HOLD | 发现可疑 preset，但阈值需校准 |
| REJECT | 无法区分真实提升与响度假象 |

---

## 输出要求

每个 AEP 完成后必须输出：

```text
实验结论
关键数据
发现的问题
建议修改
Preset Gate：ADOPT / HOLD / REJECT
是否进入下一 AEP
```

禁止只给主观听感判断，必须给出 before/after 数据。
