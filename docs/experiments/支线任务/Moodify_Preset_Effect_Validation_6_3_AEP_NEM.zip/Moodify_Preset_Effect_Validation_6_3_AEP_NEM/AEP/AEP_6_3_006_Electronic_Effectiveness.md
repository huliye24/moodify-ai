# AEP-6.3-006：Electronic Effectiveness

## 名称

电子乐类样本 preset 有效性实验

## 目标

回答：

> 哪个 preset 对电子乐有效？

## 输入

建议至少包含：

```text
electronic
edm
synth_pop
ambient_electronic
cinematic_electronic
bass_heavy
bright_synth
wide_pad
```

## 实验步骤

1. 筛选电子乐类样本。
2. 对所有电子乐样本执行 preset 对比。
3. 统计每个 preset 在电子乐样本上的 Delta_MRS。
4. 检查 wide_space 是否真正提升空间，而不是制造虚假宽度。
5. 检查 safe_air 是否改善暗闷样本。
6. 检查高频是否过亮或过暗。
7. 输出电子乐 preset 推荐表。

## 关键指标

```text
electronic_density
bass_stability
air_band_change
stereo_width_change
space_change
spectral_centroid_delta
over_bright_triggered
over_dark_triggered
Delta_MRS
```

## 判断标准

| 状态 | 标准 |
|---|---|
| ADOPT | 明确哪些 preset 适合电子乐 |
| HOLD | 电子乐效果有方向，但需细分风格 |
| REJECT | 电子乐样本上 preset 表现不稳定 |

---

## 输出要求

每个 AEP 完成后必须输出：

```text
实验结论
关键数据
发现的问题
建议修改
Preset Gate：ADOPT / HOLD / REJECT
是否进入下一 AEP
```

禁止只给主观听感判断，必须给出 before/after 数据。
