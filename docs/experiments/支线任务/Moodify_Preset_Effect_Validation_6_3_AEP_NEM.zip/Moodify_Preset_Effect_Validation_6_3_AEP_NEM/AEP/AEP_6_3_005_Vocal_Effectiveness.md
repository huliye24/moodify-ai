# AEP-6.3-005：Vocal Effectiveness

## 名称

人声类样本 preset 有效性实验

## 目标

回答：

> 哪个 preset 对人声有效？

## 输入

建议至少包含：

```text
female_vocal
male_vocal
vocal_folk
vocal_pop
spoken_vocal
soft_vocal
dense_vocal_mix
```

## 实验步骤

1. 筛选人声类样本。
2. 对所有人声样本执行 preset 对比。
3. 统计每个 preset 在人声样本上的 Delta_MRS。
4. 检查中心人声是否被空间处理破坏。
5. 检查 warm_vocal 是否导致 over_dark。
6. 检查 clean_master 是否是低风险人声默认 preset。
7. 输出人声 preset 推荐表。

## 关键指标

```text
vocal_presence
center_stability
warmth_change
over_dark_triggered
sibilance_change
MRS_before
MRS_after
Delta_MRS
```

## 判断标准

| 状态 | 标准 |
|---|---|
| ADOPT | 明确哪些 preset 适合人声 |
| HOLD | 人声效果有方向，但样本不足 |
| REJECT | 人声样本上 preset 表现混乱 |

---

## 输出要求

每个 AEP 完成后必须输出：

```text
实验结论
关键数据
发现的问题
建议修改
Preset Gate：ADOPT / HOLD / REJECT
是否进入下一 AEP
```

禁止只给主观听感判断，必须给出 before/after 数据。
