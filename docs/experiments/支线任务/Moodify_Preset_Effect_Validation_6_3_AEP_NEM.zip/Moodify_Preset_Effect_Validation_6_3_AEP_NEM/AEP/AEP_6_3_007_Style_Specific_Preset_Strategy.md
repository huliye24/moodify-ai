# AEP-6.3-007：Style Specific Preset Strategy

## 名称

按风格分 preset 策略实验

## 目标

回答：

> 是否需要按风格分 preset？

## 背景

一个 preset 不一定需要对所有风格有效。Moodify 更合理的方向可能是建立风格化工艺库：

```text
vocal_clean
vocal_warm_safe
electronic_air
cinematic_space
ambient_depth
rock_dynamic_safe
```

## 实验步骤

1. 按 style_tag 聚合样本。
2. 计算每个 style × preset 的平均 Delta_MRS。
3. 标记风格有效 preset。
4. 标记风格危险 preset。
5. 判断是否存在全局通用 preset。
6. 判断是否需要风格路由系统。

## 输出表

| style | best_preset | worst_preset | risk | recommendation |
|---|---|---|---|---|

## 判断标准

| 状态 | 标准 |
|---|---|
| ADOPT | 明确需要或不需要风格分 preset |
| HOLD | 有风格差异，但样本不足 |
| REJECT | 无法建立风格判断 |

---

## 输出要求

每个 AEP 完成后必须输出：

```text
实验结论
关键数据
发现的问题
建议修改
Preset Gate：ADOPT / HOLD / REJECT
是否进入下一 AEP
```

禁止只给主观听感判断，必须给出 before/after 数据。
