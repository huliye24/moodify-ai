# Preset Decision Table

## 决策表字段

| 字段 | 含义 |
|---|---|
| preset | preset 名称 |
| mean_delta_mrs | 平均 MRS 提升 |
| median_delta_mrs | 中位数 MRS 提升 |
| positive_rate | 提升样本比例 |
| negative_rate | 恶化样本比例 |
| loudness_cheat_rate | 响度作弊比例 |
| dynamic_damage_rate | 动态破坏比例 |
| best_styles | 最适合风格 |
| risk_styles | 高风险风格 |
| gate | ADOPT / HOLD / REJECT |
| recommendation | 生产建议 |

---

## 决策表示例

| preset | mean_delta_mrs | median_delta_mrs | positive_rate | negative_rate | loudness_cheat_rate | dynamic_damage_rate | best_styles | risk_styles | gate | recommendation |
|---|---:|---:|---:|---:|---:|---:|---|---|---|---|
| clean_master | | | | | | | | | | |
| safe_air | | | | | | | | | | |
| warm_vocal | | | | | | | | | | |
| wide_space | | | | | | | | | | |

---

## 推荐解释格式

```text
clean_master:
  Gate:
  Reason:
  Best styles:
  Risk styles:
  Recommendation:

safe_air:
  Gate:
  Reason:
  Best styles:
  Risk styles:
  Recommendation:
```
