# Moodify 6.3 Preset 效果验证执行检查清单

## 开始前

- [ ] 确认当前 MRS 版本
- [ ] 确认当前 Runtime 版本
- [ ] 确认当前 preset 列表
- [ ] 确认样本目录
- [ ] 确认输出目录
- [ ] 确认不会覆盖原始音频

## AEP-001 Before/After

- [ ] 已计算 MRS_before
- [ ] 已计算 MRS_after
- [ ] 已计算 Delta_MRS
- [ ] 已记录 LoudnessPenalty
- [ ] 已记录 OPR
- [ ] 已记录动态/空间/频谱变化

## AEP-002 Preset MRS Comparison

- [ ] 已按 preset 聚合
- [ ] 已计算 mean Delta_MRS
- [ ] 已计算 median Delta_MRS
- [ ] 已计算 positive_rate
- [ ] 已计算 negative_rate
- [ ] 已识别 worst samples

## AEP-003 Loudness Cheat

- [ ] 已记录响度变化
- [ ] 已记录 LoudnessPenalty 变化
- [ ] 已记录动态变化
- [ ] 已标记 loudness_cheat_flag

## AEP-004 Dynamic Damage

- [ ] 已记录 dynamic_range
- [ ] 已记录 crest_factor
- [ ] 已记录 transient 指标
- [ ] 已标记 dynamic_damage_flag

## AEP-005 Vocal

- [ ] 已筛选人声样本
- [ ] 已输出人声 preset 推荐
- [ ] 已识别人声危险 preset

## AEP-006 Electronic

- [ ] 已筛选电子乐样本
- [ ] 已输出电子乐 preset 推荐
- [ ] 已识别电子乐危险 preset

## AEP-007 Style Strategy

- [ ] 已按风格聚合
- [ ] 已判断是否需要风格分 preset
- [ ] 已提出 style router 建议

## AEP-008 Gate

- [ ] 已输出 preset decision table
- [ ] 每个 preset 已标注 ADOPT / HOLD / REJECT
- [ ] 已输出最终报告
