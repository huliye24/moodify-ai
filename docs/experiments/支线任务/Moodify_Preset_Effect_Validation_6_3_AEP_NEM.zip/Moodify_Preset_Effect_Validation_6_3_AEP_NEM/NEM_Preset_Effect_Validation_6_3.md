# NEM-Preset-Effect-Validation-6.3

# Moodify 支线计划 6.3：Preset 效果验证实验

## 一、节点定位

本节点是 Moodify 支线实验系统的第三个 NEM 节点，服务于 Moodify 的声音工艺库建设。

6.3 的核心目标是验证：

> Moodify 的处理 preset 是否真正提升 AI 音乐真实度，而不是制造响度、亮度、宽度或空间感的假象。

在此前 full_test_v02 中，Runtime 已经证明可以稳定执行 90 个任务，但 MRS Open v0.3.1 显示大量输出反而出现 degradation，尤其是 over_dark 问题。这说明 Moodify 已经进入一个重要阶段：

```text
Runtime 能跑 ≠ 工艺有效
处理完成 ≠ 声音变好
响度变大 ≠ 真实度提升
空间变宽 ≠ 空间更真实
高频变化 ≠ 质感更好
```

因此，6.3 的核心意义是建立 Preset Gate，让每一个声音处理工艺都必须通过数据验证。

---

## 二、实验目标

验证处理工艺是否真正提升真实度，而不是制造响度假象。

本实验重点回答：

```text
哪个 preset 能稳定提升 MRS？
哪个 preset 可能破坏动态？
哪个 preset 对人声有效？
哪个 preset 对电子乐有效？
哪个 preset 只是响度作弊？
是否需要按风格分 preset？
```

---

## 三、核心指标

本实验至少记录以下指标：

```text
MRS_before
MRS_after
Delta_MRS
LoudnessPenalty
OPR
dynamic_change
space_change
spectrum_change
```

建议扩展指标：

```text
crest_factor_before
crest_factor_after
dynamic_range_before
dynamic_range_after
lufs_before
lufs_after
spectral_centroid_before
spectral_centroid_after
air_band_before
air_band_after
stereo_width_before
stereo_width_after
over_dark_triggered
over_bright_triggered
loudness_cheat_flag
dynamic_damage_flag
style_tag
vocal_presence
electronic_density
```

---

## 四、核心判断逻辑

### 1. 真提升

一个 preset 只有满足以下条件，才能被认为是真提升：

```text
MRS_after > MRS_before
Delta_MRS > 0
LoudnessPenalty 没有明显升高
OPR 没有明显恶化
动态没有明显塌陷
频谱没有过暗或过亮
空间变化没有变成虚假宽度
```

---

### 2. 响度假象

如果出现以下情况，应判定为响度作弊或响度假象：

```text
MRS_after 看似提高
但 LUFS 明显变大
LoudnessPenalty 明显升高
动态范围下降
crest factor 下降
OPR 变差
听感可能只是“更响”
```

这种 preset 不应直接 ADOPT。

---

### 3. 动态破坏

如果出现以下情况，应判定为动态破坏：

```text
dynamic_range_after 明显低于 before
crest_factor_after 明显低于 before
瞬态变钝
峰值被压平
MRS 提升不稳定
```

动态破坏型 preset 对 AI 音乐尤其危险，因为 AI 音乐本身常有瞬态、质感和生命感不足的问题。

---

### 4. 风格适配

一个 preset 可能不是全局有效，而是风格有效。

例如：

```text
vocal_clean 可能适合人声，不适合电子乐
safe_air 可能适合暗闷样本，不适合本来就明亮的样本
wide_space 可能适合氛围音乐，但可能破坏中心人声
warm_vocal 可能让人声更厚，但可能导致 over_dark
clean_master 可能是低风险通用 preset
```

因此，6.3 需要判断：

```text
是否需要按风格分 preset？
```

---

## 五、节点拆解

| AEP | 名称 | 目标 |
|---|---|---|
| AEP-6.3-001 | Baseline Before/After | 建立 before/after 对比基线 |
| AEP-6.3-002 | Preset MRS Comparison | 比较不同 preset 的 MRS 提升能力 |
| AEP-6.3-003 | Loudness Cheat Detection | 检测响度作弊 |
| AEP-6.3-004 | Dynamic Damage Detection | 检测动态破坏 |
| AEP-6.3-005 | Vocal Effectiveness | 验证人声类样本效果 |
| AEP-6.3-006 | Electronic Effectiveness | 验证电子乐样本效果 |
| AEP-6.3-007 | Style Specific Preset Strategy | 判断是否按风格分 preset |
| AEP-6.3-008 | Preset Gate and Roadmap | 输出 preset 采纳/暂停/淘汰路线 |

---

## 六、实验输入建议

建议使用 20-50 首真实 AI 音乐样本，至少覆盖：

```text
vocal_folk
female_vocal
male_vocal
electronic
cinematic
ambient
pop
rock
hybrid
over_bright_sample
over_dark_sample
high_loudness_sample
low_dynamic_sample
```

每个样本至少运行：

```text
原始 before 分析
clean_master
safe_air
warm_vocal
wide_space
其他当前可用 preset
```

---

## 七、实验输出建议

```text
outputs/preset_validation_6_3/
logs/preset_validation_6_3/
reports/preset_effect_validation_6_3_report.md
data/preset_validation_6_3/preset_metrics.csv
data/preset_validation_6_3/preset_decision_table.csv
```

---

## 八、Gate 结论格式

每个 preset 最终都应给出单独 Gate：

```text
preset_name:
  Gate: ADOPT / HOLD / REJECT
  Reason:
  Best styles:
  Risk styles:
  Main benefit:
  Main damage:
  Production recommendation:
```

---

## 九、与主线关系

6.3 直接服务于 Moodify 的三条主线：

```text
工艺库建设
Electron 桌面端可用 preset
潮汐循环自动优化
```

如果 6.3 不完成，Moodify 的 preset 就只是“处理效果集合”；  
如果 6.3 完成，Moodify 的 preset 才开始变成“可验证声音工艺库”。
