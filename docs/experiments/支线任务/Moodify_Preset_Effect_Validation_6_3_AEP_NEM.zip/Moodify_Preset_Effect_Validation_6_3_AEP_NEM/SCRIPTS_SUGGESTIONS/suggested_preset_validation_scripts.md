# Suggested Preset Validation Scripts

## 1. Preset validation runner

```text
scripts/run_preset_validation_6_3.py
```

用途：

```text
批量计算 MRS_before
批量运行 preset
批量计算 MRS_after
输出 preset_metrics.csv
```

## 2. Preset validation analyzer

```text
scripts/analyze_preset_validation_6_3.py
```

用途：

```text
按 preset 聚合 Delta_MRS
计算 positive_rate / negative_rate
输出 preset ranking
```

## 3. Loudness cheat detector

```text
scripts/detect_loudness_cheat_6_3.py
```

用途：

```text
检测响度提升但真实度没有对应提升的 preset
```

## 4. Dynamic damage detector

```text
scripts/detect_dynamic_damage_6_3.py
```

用途：

```text
检测动态范围下降、crest factor 下降、瞬态受损
```

## 5. Style preset analyzer

```text
scripts/analyze_style_specific_presets_6_3.py
```

用途：

```text
按 vocal/electronic/ambient/cinematic/pop 分析 preset 有效性
```

## 6. Preset decision table generator

```text
scripts/generate_preset_decision_table_6_3.py
```

用途：

```text
生成 ADOPT / HOLD / REJECT 决策表
```
