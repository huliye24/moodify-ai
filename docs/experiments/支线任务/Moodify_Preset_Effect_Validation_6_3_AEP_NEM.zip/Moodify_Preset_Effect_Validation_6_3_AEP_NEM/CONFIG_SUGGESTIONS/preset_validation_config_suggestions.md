# Preset Validation Config Suggestions

## 推荐实验配置

```json
{
  "experiment": "preset_effect_validation_6_3",
  "scoring": {
    "mode": "full_mrs",
    "require_before_score": true,
    "require_after_score": true
  },
  "presets": [
    "clean_master",
    "safe_air",
    "warm_vocal",
    "wide_space"
  ],
  "metrics": {
    "mrs_before": true,
    "mrs_after": true,
    "delta_mrs": true,
    "loudness_penalty": true,
    "opr": true,
    "dynamic_change": true,
    "space_change": true,
    "spectrum_change": true
  },
  "flags": {
    "loudness_cheat": true,
    "dynamic_damage": true,
    "over_dark": true,
    "over_bright": true
  },
  "style_grouping": {
    "enabled": true,
    "required_tags": [
      "vocal",
      "electronic",
      "ambient",
      "cinematic",
      "pop"
    ]
  }
}
```

## 推荐输出

```text
data/preset_validation_6_3/preset_metrics.csv
data/preset_validation_6_3/preset_decision_table.csv
reports/preset_effect_validation_6_3_report.md
```

## Gate 阈值建议

```text
positive_rate_adopt_min = 0.60
negative_rate_adopt_max = 0.30
median_delta_mrs_adopt_min = 0
loudness_cheat_reject_rate = 0.40
dynamic_damage_reject_rate = 0.40
```

这些阈值不是最终标准，可以根据真实样本结果继续校准。
