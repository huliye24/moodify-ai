# Moodify 6.3 Preset 效果验证实验报告

## 1. 实验摘要

```text
实验名称：
实验时间：
项目根目录：
样本数量：
preset 数量：
MRS 版本：
Runtime 版本：
最终 Node Gate：
```

---

## 2. 实验目标

本实验用于验证 preset 是否真正提升 AI 音乐真实度，而不是制造响度假象。

核心问题：

```text
哪个 preset 能稳定提升 MRS？
哪个 preset 可能破坏动态？
哪个 preset 对人声有效？
哪个 preset 对电子乐有效？
哪个 preset 只是响度作弊？
是否需要按风格分 preset？
```

---

## 3. 样本列表

| sample_id | file_name | style_tag | duration_sec | input_size_mb |
|---|---|---|---:|---:|
| | | | | |

---

## 4. Preset 列表

| preset_name | status_before_test | description |
|---|---|---|
| clean_master | | |
| safe_air | | |
| warm_vocal | | |
| wide_space | | |

---

## 5. Before / After 指标表

| sample_id | style | preset | MRS_before | MRS_after | Delta_MRS | LoudnessPenalty | OPR | dynamic_change | space_change | spectrum_change |
|---|---|---|---:|---:|---:|---:|---:|---:|---:|---:|
| | | | | | | | | | | |

---

## 6. Preset 总排名

| preset | mean_delta | median_delta | positive_rate | negative_rate | risk_level | gate |
|---|---:|---:|---:|---:|---|---|
| | | | | | | |

---

## 7. 响度作弊检测

```text
是否存在响度作弊 preset：
主要证据：
涉及 preset：
涉及样本：
```

| preset | loudness_increase | loudness_penalty_delta | dynamic_drop | loudness_cheat_flag |
|---|---:|---:|---:|---|
| | | | | |

---

## 8. 动态破坏检测

```text
是否存在动态破坏：
主要证据：
涉及 preset：
涉及样本：
```

| preset | dynamic_range_delta | crest_factor_delta | transient_change | dynamic_damage_flag |
|---|---:|---:|---:|---|
| | | | | |

---

## 9. 人声样本分析

```text
人声样本数量：
最佳 preset：
最危险 preset：
是否需要人声专用 preset：
```

| preset | vocal_mean_delta | vocal_positive_rate | vocal_risk | recommendation |
|---|---:|---:|---|---|
| | | | | |

---

## 10. 电子乐样本分析

```text
电子乐样本数量：
最佳 preset：
最危险 preset：
是否需要电子乐专用 preset：
```

| preset | electronic_mean_delta | electronic_positive_rate | electronic_risk | recommendation |
|---|---:|---:|---|---|
| | | | | |

---

## 11. 是否需要按风格分 preset

结论：

```text
需要 / 暂不需要 / 需要更多样本
```

建议风格路由：

```text
vocal → 
electronic →
ambient →
cinematic →
pop →
```

---

## 12. Preset Decision Table

| preset | Gate | Best Styles | Risk Styles | Main Benefit | Main Damage | Production Recommendation |
|---|---|---|---|---|---|---|
| clean_master | | | | | | |
| safe_air | | | | | | |
| warm_vocal | | | | | | |
| wide_space | | | | | | |

---

## 13. 最终 Gate

```text
Node Gate: ADOPT / HOLD / REJECT
```

理由：

```text
...
```

下一步：

```text
...
```
