# Gate：Preset Effect Validation 6.3

## Gate 名称

Preset 效果验证 Gate

## 目标

判断 preset 是否真正提升 AI 音乐真实度，而不是制造响度假象、空间假象或动态破坏。

---

## 单个 Preset ADOPT 标准

一个 preset 满足以下条件，可判定为 ADOPT：

```text
median Delta_MRS > 0
positive_rate ≥ 60%
negative_rate ≤ 30%
LoudnessPenalty 没有系统性升高
OPR 没有系统性恶化
dynamic_damage_flag 低
loudness_cheat_flag 低
没有大规模 over_dark / over_bright
至少在一个明确风格类别中表现稳定
```

ADOPT 意味着：

> 该 preset 可以进入工艺库，或在限定场景下进入 Electron 桌面端。

---

## 单个 Preset HOLD 标准

出现以下情况，判定为 HOLD：

```text
部分样本提升，部分样本恶化
平均提升不明显，但某一风格有效
存在轻微 LoudnessPenalty 或 OPR 风险
存在 over_dark / over_bright 但可修复
需要更多样本验证
```

HOLD 意味着：

> 该 preset 暂不作为默认工艺，但可以进入实验队列继续优化。

---

## 单个 Preset REJECT 标准

出现以下情况，判定为 REJECT：

```text
median Delta_MRS ≤ 0
negative_rate > 50%
LoudnessPenalty 系统性升高
OPR 系统性恶化
动态明显塌陷
主要收益来自响度作弊
大规模 over_dark / over_bright
对核心风格没有稳定提升
```

REJECT 意味着：

> 该 preset 应暂停生产使用，不进入桌面端默认选项。

---

## 整个 6.3 节点 ADOPT 标准

满足以下条件，6.3 节点可判定 ADOPT：

```text
完成至少 20 个真实样本 before/after 对比
至少测试 3 个以上 preset
每个 preset 都有 MRS_before / MRS_after / Delta_MRS
记录 LoudnessPenalty / OPR / 动态 / 空间 / 频谱变化
完成响度作弊检测
完成动态破坏检测
完成人声和电子乐分组分析
输出 preset decision table
给出 ADOPT / HOLD / REJECT 结论
```

---

## 整个 6.3 节点 HOLD 标准

```text
样本数量不足
风格标签不完整
部分指标缺失
能看出趋势，但不足以决定默认 preset
```

---

## 整个 6.3 节点 REJECT 标准

```text
无法建立 before/after 数据
MRS 指标缺失
无法区分真实提升和响度假象
无法形成 preset 采纳/暂停/淘汰决策
```

---

## 最终 Gate 输出格式

```text
Node Gate: ADOPT / HOLD / REJECT

Preset Decisions:
- clean_master: ADOPT / HOLD / REJECT
- safe_air: ADOPT / HOLD / REJECT
- warm_vocal: ADOPT / HOLD / REJECT
- wide_space: ADOPT / HOLD / REJECT

Main Findings:
- ...

Next:
- ...
```
