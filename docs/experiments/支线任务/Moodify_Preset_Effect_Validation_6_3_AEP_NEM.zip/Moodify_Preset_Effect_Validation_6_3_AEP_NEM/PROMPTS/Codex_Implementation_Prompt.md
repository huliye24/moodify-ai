# Codex 实现 Prompt：Moodify 6.3 Preset Validation Instrumentation

请为 Moodify 项目实现 Preset 效果验证实验所需的最小代码改造。

## 目标

为当前 preset 处理流程增加 before/after 指标记录、Delta_MRS 计算、响度作弊检测、动态破坏检测和 preset decision table 输出。

---

## 需要实现

1. 对原始输入计算 MRS_before。
2. 对每个 preset 输出计算 MRS_after。
3. 自动计算 Delta_MRS。
4. 记录 LoudnessPenalty、OPR、动态、空间、频谱变化。
5. 增加 loudness_cheat_flag。
6. 增加 dynamic_damage_flag。
7. 支持 style_tag 聚合。
8. 输出 preset_metrics.csv。
9. 输出 preset_decision_table.csv。
10. 在 summary 中增加 preset Gate。

---

## 建议字段

```json
{
  "sample_id": "",
  "style_tag": "",
  "preset_name": "",
  "mrs_before": 0,
  "mrs_after": 0,
  "delta_mrs": 0,
  "loudness_penalty_before": 0,
  "loudness_penalty_after": 0,
  "opr_before": 0,
  "opr_after": 0,
  "dynamic_range_before": 0,
  "dynamic_range_after": 0,
  "crest_factor_before": 0,
  "crest_factor_after": 0,
  "spectral_centroid_before": 0,
  "spectral_centroid_after": 0,
  "air_band_before": 0,
  "air_band_after": 0,
  "stereo_width_before": 0,
  "stereo_width_after": 0,
  "loudness_cheat_flag": false,
  "dynamic_damage_flag": false,
  "over_dark_triggered": false,
  "over_bright_triggered": false,
  "preset_gate": "ADOPT|HOLD|REJECT"
}
```

---

## 不要做的事

```text
不要改变 MRS 公式
不要把响度提升等同于真实度提升
不要让缺失 MRS_before 时继续输出错误结论
不要覆盖原始音频
不要删除已有 Runtime 输出
```

---

## 输出要求

请提交：

```text
新增或修改的文件列表
如何运行 preset validation
如何查看 preset_metrics.csv
如何查看 preset_decision_table.csv
当前 preset 的 Gate 结果
已知风险
```
