# Claude 执行 Prompt：Moodify 6.3 Preset 效果验证实验

请在 Moodify 项目中执行 6.3 Preset 效果验证实验。

## 实验目标

验证当前 preset 是否真正提升 AI 音乐真实度，而不是制造响度假象。

本轮任务不是优化 MRS 公式，也不是盲目新增 preset，而是对当前 preset 做 before/after 验证和 Gate 判断。

---

## 需要回答的问题

```text
哪个 preset 能稳定提升 MRS？
哪个 preset 可能破坏动态？
哪个 preset 对人声有效？
哪个 preset 对电子乐有效？
哪个 preset 只是响度作弊？
是否需要按风格分 preset？
```

---

## 必须记录的指标

```text
MRS_before
MRS_after
Delta_MRS
LoudnessPenalty
OPR
动态变化
空间变化
频谱变化
```

建议扩展：

```text
LUFS before/after
dynamic_range before/after
crest_factor before/after
spectral_centroid before/after
air_band before/after
stereo_width before/after
over_dark_triggered
over_bright_triggered
loudness_cheat_flag
dynamic_damage_flag
style_tag
```

---

## 执行步骤

1. 选择 20-50 首真实 AI 音乐样本。
2. 为样本添加 style_tag，例如 vocal、electronic、ambient、cinematic、pop。
3. 对原始样本计算 MRS_before。
4. 用当前 preset 处理每个样本。
5. 对处理结果计算 MRS_after。
6. 计算 Delta_MRS。
7. 对每个 preset 聚合统计：
   - mean Delta_MRS
   - median Delta_MRS
   - positive_rate
   - negative_rate
   - LoudnessPenalty 变化
   - OPR 变化
   - 动态变化
   - 空间变化
   - 频谱变化
8. 检测 loudness cheat。
9. 检测 dynamic damage。
10. 分析人声样本上的 preset 表现。
11. 分析电子乐样本上的 preset 表现。
12. 判断是否需要按风格分 preset。
13. 输出 preset decision table。
14. 给每个 preset 标注 ADOPT / HOLD / REJECT。

---

## 输出路径建议

```text
outputs/preset_validation_6_3/
logs/preset_validation_6_3/
reports/preset_effect_validation_6_3_report.md
data/preset_validation_6_3/preset_metrics.csv
data/preset_validation_6_3/preset_decision_table.csv
```

---

## 最终报告必须包含

```text
实验摘要
样本列表
preset 列表
before/after 指标表
preset 总排名
响度作弊检测
动态破坏检测
人声样本分析
电子乐样本分析
按风格分 preset 建议
Preset Decision Table
Gate：ADOPT / HOLD / REJECT
```

---

## 注意

不要只写“听起来更好”。必须用数据说明 preset 是否真正提升真实度。
