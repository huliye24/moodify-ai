# Gate：Sample Library Coverage 6.4

## Gate 名称

样本库覆盖实验 Gate

## 目标

判断 Moodify 样本库是否已经具备代表真实 AI 音乐生态的初步能力。

---

## ADOPT 标准

满足以下条件，可判定为 ADOPT：

```text
总样本数 ≥ 30
覆盖 Suno 与 Udio
至少覆盖 6 个主要风格
至少覆盖中文、英文、法语、器乐
至少覆盖高质量、普通、明显塑料感三类质量层
至少覆盖短音频、中等音频、完整歌曲
sample_registry.jsonl 存在
metadata 完整率 ≥ 95%
sha256 hash 完整率 = 100%
有明确 license_status 字段
有覆盖矩阵
有缺口报告
有下一阶段样本扩展路线
```

ADOPT 意味着：

> 样本库可以支撑 MRS、Preset、Runtime、潮汐循环和 Electron 桌面端的下一阶段实验。

---

## HOLD 标准

出现以下情况，判定为 HOLD：

```text
总样本数 15-30
覆盖 Suno，但 Udio 或其他平台不足
风格覆盖不足 6 类
语言覆盖不足
塑料感负样本不足
完整歌曲不足
metadata 完整率 80%-95%
有 registry，但标签不完整
```

HOLD 意味着：

> 样本库可以用于初步实验，但不能作为稳定 Benchmark。

---

## REJECT 标准

出现以下情况，判定为 REJECT：

```text
总样本数 < 15
只有单一平台
只有单一风格
只有单一语言
无质量层级
无完整歌曲
无 sample_registry
metadata 缺失严重
无法判断授权状态
```

REJECT 意味着：

> 样本库不足以代表真实 AI 音乐生态，不能继续作为工艺判断依据。

---

## 关键 Gate 指标

```text
total_sample_count
platform_coverage_score
genre_coverage_score
language_coverage_score
quality_coverage_score
duration_coverage_score
metadata_completeness_rate
hash_completeness_rate
license_status_completeness_rate
coverage_gap_count
```

---

## 最终 Gate 输出格式

```text
Node Gate: ADOPT / HOLD / REJECT

Main Findings:
- ...

Coverage Gaps:
- ...

Next Sample Priorities:
- ...
```
