# Claude 执行 Prompt：Moodify 6.4 样本库覆盖实验

请在 Moodify 项目中执行 6.4 样本库覆盖实验。

## 实验目标

建立能代表真实 AI 音乐生态的样本集，并判断当前样本库是否足以支撑 Moodify 的 MRS、Preset、Runtime、潮汐循环和 Electron 桌面端实验。

---

## 需要覆盖的样本维度

```text
Suno / Udio / 其他生成平台
人声 / 器乐 / 电子 / 民谣 / 摇滚 / 电影感
中文 / 英文 / 法语 / 其他语言
高质量样本 / 普通样本 / 明显塑料感样本
短音频 / 中等音频 / 完整歌曲
```

---

## 执行步骤

1. 扫描当前样本目录。
2. 为每个样本生成 sample_id。
3. 计算每个文件的 sha256。
4. 记录 file_name、file_path、duration_sec、format、sample_rate、channels、size_mb。
5. 为每个样本标注 platform。
6. 为每个样本标注 genre_tags。
7. 为每个样本标注 language_tags。
8. 为每个样本标注 quality_tier。
9. 为每个样本标注 problem_tags。
10. 自动生成 duration_tier。
11. 生成 sample_registry.jsonl。
12. 生成 coverage matrix。
13. 输出覆盖缺口报告。
14. 给出 ADOPT / HOLD / REJECT Gate。

---

## 输出路径建议

```text
data/sample_library/raw/
data/sample_library/processed/
data/sample_library/sample_registry.jsonl
reports/sample_library_coverage_6_4_report.md
outputs/sample_library_coverage_6_4/coverage_matrix.csv
outputs/sample_library_coverage_6_4/coverage_gaps.md
```

---

## 最终报告必须包含

```text
实验摘要
样本总量
平台覆盖
风格覆盖
语言覆盖
质量层级覆盖
长度覆盖
metadata 完整度
重复样本检查
授权状态检查
覆盖矩阵
缺口报告
下一阶段样本补充计划
Gate：ADOPT / HOLD / REJECT
```

---

## 注意

请不要随意删除、移动或覆盖原始样本。原始样本必须只读保存，处理结果另存。
