# Codex 实现 Prompt：Moodify 6.4 Sample Library Registry

请为 Moodify 项目实现样本库覆盖实验所需的最小代码工具。

## 目标

建立 sample_registry.jsonl、coverage_matrix.csv 和 coverage_gaps.md。

---

## 需要实现

1. 扫描样本目录。
2. 计算每个音频文件的 sha256。
3. 读取音频 duration、sample_rate、channels、format、size_mb。
4. 为每个文件生成稳定 sample_id。
5. 生成 sample_registry.jsonl。
6. 检查 metadata 完整率。
7. 检查重复 hash。
8. 生成平台/风格/语言/质量/长度覆盖统计。
9. 输出 coverage_matrix.csv。
10. 输出 coverage_gaps.md。
11. 输出 summary JSON。

---

## 建议命令

```bash
python3 scripts/build_sample_registry_6_4.py \
  --input data/sample_library/raw \
  --registry data/sample_library/sample_registry.jsonl \
  --out outputs/sample_library_coverage_6_4
```

---

## 建议字段

```json
{
  "sample_id": "",
  "file_name": "",
  "file_path": "",
  "sha256": "",
  "platform": "suno|udio|other|unknown",
  "genre_tags": [],
  "language_tags": [],
  "quality_tier": "high|normal|plastic|damaged|unknown",
  "problem_tags": [],
  "duration_sec": 0,
  "duration_tier": "short|medium|full_song|long",
  "format": "",
  "sample_rate": 0,
  "channels": 0,
  "size_mb": 0,
  "license_status": "owned|authorized|unknown|restricted",
  "created_at": "",
  "registered_at": "",
  "notes": ""
}
```

---

## 不要做的事

```text
不要覆盖原始样本
不要删除未知来源样本
不要把未知授权状态标为可用
不要把标签写死在文件名中
不要让缺失 metadata 的样本静默通过
```

---

## 输出要求

请提交：

```text
新增或修改的文件列表
运行命令
生成文件路径
覆盖统计结果
缺口报告摘要
Gate 建议
```
