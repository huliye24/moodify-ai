# Moodify 6.4 样本库覆盖实验报告

## 1. 实验摘要

```text
实验名称：
实验时间：
项目根目录：
样本目录：
总样本数：
最终 Gate：
```

---

## 2. 实验目标

建立能代表真实 AI 音乐生态的样本集。

核心维度：

```text
Suno / Udio / 其他生成平台
人声 / 器乐 / 电子 / 民谣 / 摇滚 / 电影感
中文 / 英文 / 法语 / 其他语言
高质量样本 / 普通样本 / 明显塑料感样本
短音频 / 中等音频 / 完整歌曲
```

---

## 3. 样本总览

| 指标 | 数值 |
|---|---:|
| 总样本数 | |
| 已注册样本 | |
| hash 完整率 | |
| metadata 完整率 | |
| 重复 hash 数量 | |
| 授权状态完整率 | |

---

## 4. 平台覆盖

| platform | count | percentage | status |
|---|---:|---:|---|
| Suno | | | |
| Udio | | | |
| Other | | | |
| Unknown | | | |

结论：

```text
...
```

---

## 5. 风格覆盖

| genre | count | percentage | status |
|---|---:|---:|---|
| vocal | | | |
| instrumental | | | |
| electronic | | | |
| folk | | | |
| rock | | | |
| cinematic | | | |
| ambient | | | |
| pop | | | |
| hybrid | | | |

结论：

```text
...
```

---

## 6. 语言覆盖

| language | count | percentage | status |
|---|---:|---:|---|
| zh | | | |
| en | | | |
| fr | | | |
| other | | | |
| instrumental | | | |

结论：

```text
...
```

---

## 7. 质量层级覆盖

| quality_tier | count | percentage | status |
|---|---:|---:|---|
| high_quality | | | |
| normal | | | |
| plastic | | | |
| damaged | | | |
| unknown | | | |

结论：

```text
...
```

---

## 8. 长度覆盖

| duration_tier | definition | count | status |
|---|---|---:|---|
| short | 0-60s | | |
| medium | 1-3min | | |
| full_song | 3-6min | | |
| long | 6min+ | | |

结论：

```text
...
```

---

## 9. 覆盖矩阵

### Platform × Genre

| platform / genre | vocal | instrumental | electronic | folk | rock | cinematic |
|---|---:|---:|---:|---:|---:|---:|
| Suno | | | | | | |
| Udio | | | | | | |
| Other | | | | | | |

### Language × Genre

| language / genre | vocal | electronic | folk | rock | cinematic |
|---|---:|---:|---:|---:|---:|
| zh | | | | | |
| en | | | | | |
| fr | | | | | |
| other | | | | | |

### Quality × Genre

| quality / genre | vocal | electronic | folk | rock | cinematic |
|---|---:|---:|---:|---:|---:|
| high | | | | | |
| normal | | | | | |
| plastic | | | | | |

---

## 10. 主要缺口

```text
平台缺口：
风格缺口：
语言缺口：
质量缺口：
长度缺口：
metadata 缺口：
授权状态缺口：
```

---

## 11. 下一阶段样本补充计划

| priority | sample type | reason | target count |
|---|---|---|---:|
| P0 | | | |
| P1 | | | |
| P2 | | | |

---

## 12. Gate 判断

```text
Node Gate: ADOPT / HOLD / REJECT
```

理由：

```text
...
```

下一步：

```text
...
```
