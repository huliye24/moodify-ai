# Suggested Sample Library Scripts

## 1. Build sample registry

```text
scripts/build_sample_registry_6_4.py
```

用途：

```text
扫描 raw 样本目录
生成 sample_id
计算 sha256
读取音频 metadata
生成 sample_registry.jsonl
```

## 2. Analyze sample coverage

```text
scripts/analyze_sample_coverage_6_4.py
```

用途：

```text
读取 sample_registry.jsonl
统计 platform / genre / language / quality / duration 覆盖
输出 coverage_matrix.csv
```

## 3. Detect duplicate samples

```text
scripts/detect_duplicate_samples_6_4.py
```

用途：

```text
基于 sha256 检查重复文件
基于 duration + size + filename 检查疑似重复样本
```

## 4. Generate coverage gaps

```text
scripts/generate_sample_coverage_gaps_6_4.py
```

用途：

```text
根据覆盖目标输出缺口报告
给出 P0/P1/P2 补样本建议
```

## 5. Validate sample metadata

```text
scripts/validate_sample_metadata_6_4.py
```

用途：

```text
检查 metadata 完整率
检查 license_status
检查 unknown 字段比例
```
