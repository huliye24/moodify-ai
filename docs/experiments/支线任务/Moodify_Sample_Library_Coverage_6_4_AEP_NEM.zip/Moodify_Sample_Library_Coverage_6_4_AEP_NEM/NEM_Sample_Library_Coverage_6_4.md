# NEM-Sample-Library-Coverage-6.4

# Moodify 支线计划 6.4：样本库覆盖实验

## 一、节点定位

本节点是 Moodify 支线实验系统中的第四个 NEM 节点。

它的核心目标是建立一个能够代表真实 AI 音乐生态的样本集。

Moodify 的本质不是处理一两首歌，而是不断从大量 AI 音乐样本中提炼声音问题、工艺规律、MRS 标准和 preset 策略。

因此，样本库不是“素材库”，而是 Moodify 的声音世界入口。

样本库决定：

```text
MRS 会被什么样的声音校准
Preset 会被什么样的声音训练
潮汐循环会反复处理什么样的问题
工艺库会长出什么样的性格
Electron 桌面端默认体验会偏向什么风格
未来 B 端客户能否覆盖真实市场需求
```

---

## 二、实验目标

建立能代表真实 AI 音乐生态的样本集。

具体目标：

1. 覆盖主要 AI 音乐生成平台。
2. 覆盖主要音乐类型。
3. 覆盖主要语言。
4. 覆盖不同质量层级。
5. 覆盖不同音频长度。
6. 建立样本 metadata schema。
7. 建立样本注册表。
8. 建立覆盖矩阵与缺口报告。

---

## 三、样本维度

### 1. 平台维度

```text
Suno
Udio
其他生成平台
未知平台
```

### 2. 风格维度

```text
人声
器乐
电子
民谣
摇滚
电影感
环境氛围
流行
混合风格
```

### 3. 语言维度

```text
中文
英文
法语
日语
韩语
西班牙语
其他语言
无歌词 / 器乐
```

### 4. 质量维度

```text
高质量样本
普通样本
明显塑料感样本
过亮样本
过暗样本
动态塌陷样本
空间虚假样本
人声不真实样本
```

### 5. 长度维度

```text
短音频：0-60 秒
中等音频：1-3 分钟
完整歌曲：3-6 分钟
长音频：6 分钟以上
```

---

## 四、战略意义

样本库决定 Moodify 的工艺库性格。

如果样本库只包含高质量 AI 音乐，Moodify 可能无法识别低质量样本的问题。  
如果样本库只包含英文歌曲，Moodify 可能无法处理中文、法语、日语等语言的人声质感。  
如果样本库只包含电子乐，Moodify 可能会把电子乐的声音审美误当作全局标准。  
如果样本库缺少明显塑料感样本，Moodify 的 MRS 和 preset 会缺少负样本参照。

因此，6.4 不是“多收一点样本”，而是建立 Moodify 的声音地基。

---

## 五、节点拆解

| AEP | 名称 | 目标 |
|---|---|---|
| AEP-6.4-001 | Sample Taxonomy | 建立样本分类体系 |
| AEP-6.4-002 | Platform Coverage | 覆盖 Suno / Udio / 其他平台 |
| AEP-6.4-003 | Genre Style Coverage | 覆盖人声、器乐、电子、民谣、摇滚、电影感 |
| AEP-6.4-004 | Language Coverage | 覆盖中文、英文、法语、其他语言 |
| AEP-6.4-005 | Quality Tier Labeling | 建立高质量/普通/塑料感等质量标签 |
| AEP-6.4-006 | Duration Coverage | 覆盖短音频、中等音频、完整歌曲 |
| AEP-6.4-007 | Metadata Registry | 建立样本注册表与 metadata schema |
| AEP-6.4-008 | Coverage Gap And Roadmap | 输出覆盖缺口与扩展路线 |

---

## 六、最小可用样本集建议

初始 MVP 阶段建议至少建立：

```text
总样本数：30-60 首
平台：至少 Suno + Udio
风格：至少 6 类
语言：至少 4 类
质量层级：至少 3 类
长度层级：至少 3 类
```

建议初始结构：

| 维度 | 最小数量 |
|---|---:|
| Suno | 15 |
| Udio | 10 |
| 其他平台 | 5 |
| 人声 | 15 |
| 器乐 | 10 |
| 电子 | 10 |
| 民谣 | 5 |
| 摇滚 | 5 |
| 电影感 | 5 |
| 中文 | 8 |
| 英文 | 10 |
| 法语 | 6 |
| 其他语言 | 6 |
| 高质量 | 10 |
| 普通 | 15 |
| 明显塑料感 | 10 |
| 短音频 | 10 |
| 中等音频 | 15 |
| 完整歌曲 | 15 |

---

## 七、样本入库原则

### 1. 来源可追踪

每个样本必须有：

```text
platform
generated_at
prompt_or_source_note
license_status
original_file_path
hash
```

### 2. 不污染原始样本

原始样本必须只读保存：

```text
data/sample_library/raw/
```

处理结果另存：

```text
data/sample_library/processed/
```

### 3. metadata 先于实验

任何样本进入 MRS、preset、Runtime 实验前，必须先注册 metadata。

### 4. 标签允许多值

一个样本可能同时是：

```text
Suno + French + vocal + cinematic + high_quality + full_song
```

因此标签应支持多值，而不是单一分类。

---

## 八、核心指标

```text
total_sample_count
platform_coverage
genre_coverage
language_coverage
quality_tier_coverage
duration_coverage
metadata_completeness
hash_completeness
license_status_completeness
coverage_gap_count
minimum_viable_sample_set_pass
```

---

## 九、Gate 结论

本节点最终给出：

```text
ADOPT：样本库可支撑 6.3 / MRS / preset / 潮汐循环
HOLD：样本库初步可用，但分布不均，需要扩展
REJECT：样本库不足以代表真实 AI 音乐生态
```

---

## 十、与后续节点关系

6.4 完成后，将支撑：

```text
6.3 Preset 效果验证实验
6.5 样本资产库标准化实验
6.6 报告与可解释性系统实验
6.7 潮汐循环样本扩展实验
Electron 桌面端示例库
Moodify Benchmark 样本集
```
