# Sample Library Config Suggestions

## 推荐目录结构

```text
data/sample_library/
├── raw/
│   ├── suno/
│   ├── udio/
│   ├── other/
│   └── unknown/
├── processed/
├── registry/
│   └── sample_registry.jsonl
├── manifests/
└── README.md
```

## 推荐配置

```json
{
  "sample_library": {
    "raw_dir": "data/sample_library/raw",
    "processed_dir": "data/sample_library/processed",
    "registry_path": "data/sample_library/registry/sample_registry.jsonl",
    "hash_algorithm": "sha256",
    "require_license_status": true,
    "allow_unknown_platform": true,
    "allow_unknown_quality": true
  },
  "coverage_targets": {
    "min_total_samples": 30,
    "min_platforms": 2,
    "min_genres": 6,
    "min_languages": 4,
    "min_quality_tiers": 3,
    "min_duration_tiers": 3
  }
}
```

## 标签建议

```json
{
  "platform": ["suno", "udio", "other", "unknown"],
  "genre_tags": ["vocal", "instrumental", "electronic", "folk", "rock", "cinematic", "ambient", "pop", "hybrid"],
  "language_tags": ["zh", "en", "fr", "ja", "ko", "es", "instrumental", "other"],
  "quality_tier": ["high", "normal", "plastic", "damaged", "unknown"],
  "duration_tier": ["short", "medium", "full_song", "long"],
  "problem_tags": ["over_dark", "over_bright", "plastic", "dynamic_flat", "fake_space", "vocal_artifact", "muddy", "harsh", "thin", "noisy"]
}
```
