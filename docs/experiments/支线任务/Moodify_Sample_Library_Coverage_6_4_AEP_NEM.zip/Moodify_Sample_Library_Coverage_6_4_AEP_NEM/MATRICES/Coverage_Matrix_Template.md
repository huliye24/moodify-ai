# Coverage Matrix Template

## Platform × Genre

| platform / genre | vocal | instrumental | electronic | folk | rock | cinematic | ambient | pop |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
| Suno | | | | | | | | |
| Udio | | | | | | | | |
| Other | | | | | | | | |
| Unknown | | | | | | | | |

## Language × Genre

| language / genre | vocal | instrumental | electronic | folk | rock | cinematic | ambient | pop |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
| zh | | | | | | | | |
| en | | | | | | | | |
| fr | | | | | | | | |
| other | | | | | | | | |
| instrumental | | | | | | | | |

## Quality × Genre

| quality / genre | vocal | instrumental | electronic | folk | rock | cinematic | ambient | pop |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
| high | | | | | | | | |
| normal | | | | | | | | |
| plastic | | | | | | | | |
| damaged | | | | | | | | |
| unknown | | | | | | | | |

## Duration × Genre

| duration / genre | vocal | instrumental | electronic | folk | rock | cinematic | ambient | pop |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
| short | | | | | | | | |
| medium | | | | | | | | |
| full_song | | | | | | | | |
| long | | | | | | | | |
