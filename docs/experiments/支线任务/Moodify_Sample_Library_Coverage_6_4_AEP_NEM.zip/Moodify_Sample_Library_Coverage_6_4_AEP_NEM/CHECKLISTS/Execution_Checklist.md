# Moodify 6.4 样本库覆盖执行检查清单

## 开始前

- [ ] 确认样本目录
- [ ] 确认不会覆盖原始样本
- [ ] 确认 registry 输出路径
- [ ] 确认覆盖目标
- [ ] 确认授权状态字段存在

## AEP-001 Taxonomy

- [ ] 已定义 platform 标签
- [ ] 已定义 genre 标签
- [ ] 已定义 language 标签
- [ ] 已定义 quality 标签
- [ ] 已定义 duration 标签
- [ ] 已定义 problem 标签

## AEP-002 Platform

- [ ] 已统计 Suno 样本
- [ ] 已统计 Udio 样本
- [ ] 已统计其他平台样本
- [ ] 已识别 unknown 平台

## AEP-003 Genre

- [ ] 已统计人声样本
- [ ] 已统计器乐样本
- [ ] 已统计电子样本
- [ ] 已统计民谣样本
- [ ] 已统计摇滚样本
- [ ] 已统计电影感样本

## AEP-004 Language

- [ ] 已统计中文样本
- [ ] 已统计英文样本
- [ ] 已统计法语样本
- [ ] 已统计其他语言样本
- [ ] 已统计器乐无歌词样本

## AEP-005 Quality

- [ ] 已标注高质量样本
- [ ] 已标注普通样本
- [ ] 已标注明显塑料感样本
- [ ] 已标注 problem_tags

## AEP-006 Duration

- [ ] 已统计短音频
- [ ] 已统计中等音频
- [ ] 已统计完整歌曲
- [ ] 已统计长音频

## AEP-007 Registry

- [ ] 已生成 sample_id
- [ ] 已计算 sha256
- [ ] 已生成 sample_registry.jsonl
- [ ] 已检查重复 hash
- [ ] 已检查 metadata 完整率

## AEP-008 Gap & Roadmap

- [ ] 已生成覆盖矩阵
- [ ] 已输出缺口报告
- [ ] 已给出补样本优先级
- [ ] 已输出最终 Gate
