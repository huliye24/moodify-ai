# AEP-6.4-006：Duration Coverage

## 名称

音频长度覆盖实验

## 目标

验证样本库是否覆盖短音频、中等音频和完整歌曲。

## 长度层级

```text
short：0-60 秒
medium：1-3 分钟
full_song：3-6 分钟
long：6 分钟以上
```

## 实验步骤

1. 统计每个样本 duration_sec。
2. 自动分配 duration_tier。
3. 检查是否只有短样本。
4. 检查完整歌曲数量是否足够。
5. 输出 duration × platform / duration × genre 覆盖矩阵。

## 关键指标

```text
short_count
medium_count
full_song_count
long_count
duration_gap_count
```

## 判断标准

| 状态 | 标准 |
|---|---|
| ADOPT | 短音频、中等音频、完整歌曲均有覆盖 |
| HOLD | 缺少长音频或完整歌曲不足 |
| REJECT | 只有测试短样本，无法代表真实产品场景 |

---

## 输出要求

每个 AEP 完成后必须输出：

```text
实验结论
覆盖数据
发现的缺口
建议补充样本
Gate 状态：ADOPT / HOLD / REJECT
是否进入下一 AEP
```

禁止只说“样本够了”，必须给出覆盖矩阵和缺口说明。
