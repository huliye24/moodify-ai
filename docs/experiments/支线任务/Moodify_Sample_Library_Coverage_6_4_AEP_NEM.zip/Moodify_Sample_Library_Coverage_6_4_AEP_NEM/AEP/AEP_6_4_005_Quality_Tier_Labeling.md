# AEP-6.4-005：Quality Tier Labeling

## 名称

质量层级标注实验

## 目标

建立高质量、普通、明显塑料感等质量层级，避免样本库只有正样本或只有负样本。

## 质量层级

```text
high_quality
normal
plastic
damaged
unknown
```

## 问题标签

```text
plastic
over_dark
over_bright
dynamic_flat
fake_space
vocal_artifact
muddy
harsh
thin
noisy
```

## 实验步骤

1. 为每个样本标注 quality_tier。
2. 为每个样本标注 problem_tags。
3. 检查是否有足够高质量样本作为正参照。
4. 检查是否有足够塑料感样本作为负参照。
5. 检查是否有普通样本代表真实用户输入。
6. 输出 quality × problem 覆盖矩阵。

## 关键指标

```text
high_quality_count
normal_count
plastic_count
damaged_count
unknown_quality_count
problem_tag_coverage
```

## 判断标准

| 状态 | 标准 |
|---|---|
| ADOPT | 高质量、普通、塑料感样本均有覆盖 |
| HOLD | 有质量层级，但负样本不足 |
| REJECT | 无质量标签或只有单一质量层 |

---

## 输出要求

每个 AEP 完成后必须输出：

```text
实验结论
覆盖数据
发现的缺口
建议补充样本
Gate 状态：ADOPT / HOLD / REJECT
是否进入下一 AEP
```

禁止只说“样本够了”，必须给出覆盖矩阵和缺口说明。
