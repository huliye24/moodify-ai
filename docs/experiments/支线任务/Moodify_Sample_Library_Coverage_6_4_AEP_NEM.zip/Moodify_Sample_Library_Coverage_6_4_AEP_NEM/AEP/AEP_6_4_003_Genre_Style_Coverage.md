# AEP-6.4-003：Genre Style Coverage

## 名称

风格覆盖实验

## 目标

验证样本库是否覆盖 AI 音乐生态中的主要风格类型。

## 需要覆盖

```text
人声
器乐
电子
民谣
摇滚
电影感
环境氛围
流行
混合风格
```

## 实验步骤

1. 统计每个样本的 genre_tags。
2. 计算每个风格的样本数量。
3. 检查是否存在风格过度集中。
4. 检查每个风格是否同时覆盖不同质量层级。
5. 输出 genre × quality 覆盖矩阵。

## 关键指标

```text
vocal_count
instrumental_count
electronic_count
folk_count
rock_count
cinematic_count
ambient_count
pop_count
hybrid_count
genre_gap_count
```

## 判断标准

| 状态 | 标准 |
|---|---|
| ADOPT | 至少覆盖 6 个主要风格 |
| HOLD | 覆盖 4-5 个风格，但分布不均 |
| REJECT | 风格高度单一 |

---

## 输出要求

每个 AEP 完成后必须输出：

```text
实验结论
覆盖数据
发现的缺口
建议补充样本
Gate 状态：ADOPT / HOLD / REJECT
是否进入下一 AEP
```

禁止只说“样本够了”，必须给出覆盖矩阵和缺口说明。
