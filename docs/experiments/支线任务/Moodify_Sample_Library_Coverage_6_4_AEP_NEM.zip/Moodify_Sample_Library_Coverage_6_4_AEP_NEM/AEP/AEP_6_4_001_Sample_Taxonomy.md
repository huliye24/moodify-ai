# AEP-6.4-001：Sample Taxonomy

## 名称

样本分类体系建立

## 目标

建立 Moodify 样本库的基础分类体系，使后续所有样本都能被统一标注、检索、统计和用于实验。

## 核心分类

```text
platform
genre_tags
language_tags
quality_tier
duration_tier
problem_tags
vocal_type
instrumentation
use_case
```

## 实验步骤

1. 梳理当前已有样本。
2. 为样本定义平台标签。
3. 为样本定义风格标签。
4. 为样本定义语言标签。
5. 为样本定义质量标签。
6. 为样本定义长度标签。
7. 为样本定义问题标签。
8. 输出统一 taxonomy 表。

## 推荐标签

```text
platform: suno / udio / other / unknown
genre: vocal / instrumental / electronic / folk / rock / cinematic / ambient / pop / hybrid
language: zh / en / fr / ja / ko / es / instrumental / other
quality_tier: high / normal / plastic / damaged / unknown
duration_tier: short / medium / full_song / long
problem_tags: over_dark / over_bright / plastic / dynamic_flat / fake_space / vocal_artifact / noisy
```

## 判断标准

| 状态 | 标准 |
|---|---|
| ADOPT | taxonomy 可覆盖当前样本与未来扩展 |
| HOLD | taxonomy 可用但标签需要补充 |
| REJECT | 分类体系混乱，无法统计覆盖 |

---

## 输出要求

每个 AEP 完成后必须输出：

```text
实验结论
覆盖数据
发现的缺口
建议补充样本
Gate 状态：ADOPT / HOLD / REJECT
是否进入下一 AEP
```

禁止只说“样本够了”，必须给出覆盖矩阵和缺口说明。
