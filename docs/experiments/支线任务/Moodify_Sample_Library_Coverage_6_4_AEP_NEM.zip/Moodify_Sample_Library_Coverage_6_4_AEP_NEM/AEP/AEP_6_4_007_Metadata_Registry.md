# AEP-6.4-007：Metadata Registry

## 名称

样本注册表与 metadata schema 建立

## 目标

建立样本库的正式注册表，使每个样本都有唯一 ID、来源、标签、hash 和实验可追踪记录。

## 必填字段

```text
sample_id
file_name
file_path
sha256
platform
genre_tags
language_tags
quality_tier
duration_sec
duration_tier
license_status
created_at
registered_at
notes
```

## 实验步骤

1. 为每个样本生成 sample_id。
2. 计算文件 hash。
3. 建立 sample_registry.jsonl。
4. 检查 metadata 完整率。
5. 检查重复文件。
6. 检查缺失字段。
7. 输出 registry 健康报告。

## 关键指标

```text
metadata_completeness_rate
hash_completeness_rate
duplicate_hash_count
missing_platform_count
missing_genre_count
missing_language_count
missing_quality_count
```

## 判断标准

| 状态 | 标准 |
|---|---|
| ADOPT | metadata 完整率 ≥ 95%，hash 完整 |
| HOLD | metadata 完整率 80%-95% |
| REJECT | metadata 缺失严重，无法作为资产库 |

---

## 输出要求

每个 AEP 完成后必须输出：

```text
实验结论
覆盖数据
发现的缺口
建议补充样本
Gate 状态：ADOPT / HOLD / REJECT
是否进入下一 AEP
```

禁止只说“样本够了”，必须给出覆盖矩阵和缺口说明。
