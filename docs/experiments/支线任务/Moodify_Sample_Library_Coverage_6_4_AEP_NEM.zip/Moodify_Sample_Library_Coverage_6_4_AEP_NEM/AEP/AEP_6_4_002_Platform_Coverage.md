# AEP-6.4-002：Platform Coverage

## 名称

平台覆盖实验

## 目标

验证样本库是否覆盖真实 AI 音乐生成平台。

## 需要覆盖

```text
Suno
Udio
其他生成平台
未知平台
```

## 实验步骤

1. 统计每个样本的 platform 字段。
2. 计算各平台样本数量。
3. 检查是否只有单一平台。
4. 检查每个平台是否覆盖多个风格。
5. 输出平台覆盖矩阵。

## 关键指标

```text
suno_count
udio_count
other_platform_count
unknown_platform_count
platform_diversity_score
```

## 判断标准

| 状态 | 标准 |
|---|---|
| ADOPT | 至少覆盖 Suno + Udio + 其他平台样本 |
| HOLD | 覆盖 Suno，但 Udio / 其他平台不足 |
| REJECT | 只有单一平台，无法代表真实生态 |

---

## 输出要求

每个 AEP 完成后必须输出：

```text
实验结论
覆盖数据
发现的缺口
建议补充样本
Gate 状态：ADOPT / HOLD / REJECT
是否进入下一 AEP
```

禁止只说“样本够了”，必须给出覆盖矩阵和缺口说明。
