# AEP-6.4-004：Language Coverage

## 名称

语言覆盖实验

## 目标

验证样本库是否覆盖不同语言的人声质感。

## 需要覆盖

```text
中文
英文
法语
日语 / 韩语 / 西班牙语 / 其他语言
器乐无歌词
```

## 背景

不同语言的人声发音、齿音、鼻音、元音、辅音密度不同，会影响 MRS、人声真实度、频谱判断和 preset 效果。

## 实验步骤

1. 统计 language_tags。
2. 检查是否包含中文、英文、法语。
3. 检查是否包含无歌词器乐。
4. 检查不同语言是否覆盖不同质量层级。
5. 输出 language × genre 覆盖矩阵。

## 关键指标

```text
zh_count
en_count
fr_count
other_language_count
instrumental_count
language_gap_count
```

## 判断标准

| 状态 | 标准 |
|---|---|
| ADOPT | 至少覆盖中文、英文、法语、器乐 |
| HOLD | 覆盖 2-3 类语言 |
| REJECT | 语言过于单一 |

---

## 输出要求

每个 AEP 完成后必须输出：

```text
实验结论
覆盖数据
发现的缺口
建议补充样本
Gate 状态：ADOPT / HOLD / REJECT
是否进入下一 AEP
```

禁止只说“样本够了”，必须给出覆盖矩阵和缺口说明。
