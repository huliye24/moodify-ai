# Moodify 支线计划 6.4：样本库覆盖实验 AEP-NEM 包

## 节点名称

**NEM-Sample-Library-Coverage-6.4**

中文名：**样本库覆盖节点**

## 节点定位

6.4 是 Moodify 支线实验系统中的第四个 NEM 节点。

6.1 验证 Runtime 是否稳定。  
6.2 解释 MRS 为什么慢。  
6.3 验证 preset 是否真正提升真实度。  
6.4 要解决的是更底层的问题：

> Moodify 用什么样的 AI 音乐样本来形成自己的声音判断？

样本库不是普通素材文件夹，而是 Moodify 工艺库、MRS 校准、preset 验证、潮汐循环和未来产品性格的基础数据资产。

如果样本库偏向电子乐，Moodify 的工艺库会偏向电子乐。  
如果样本库偏向人声，Moodify 的工艺库会偏向人声。  
如果样本库只收高质量样本，Moodify 可能无法识别塑料感问题。  
如果样本库缺少多语言，Moodify 可能无法处理全球 AI 音乐创作者的真实需求。

因此，6.4 的核心命题是：

> 样本库决定 Moodify 的工艺库性格。

---

## 样本维度

```text
Suno / Udio / 其他生成平台
人声 / 器乐 / 电子 / 民谣 / 摇滚 / 电影感
中文 / 英文 / 法语 / 其他语言
高质量样本 / 普通样本 / 明显塑料感样本
短音频 / 中等音频 / 完整歌曲
```

---

## 包结构

```text
Moodify_Sample_Library_Coverage_6_4_AEP_NEM/
├── README.md
├── NEM_Sample_Library_Coverage_6_4.md
├── AEP/
│   ├── AEP_6_4_001_Sample_Taxonomy.md
│   ├── AEP_6_4_002_Platform_Coverage.md
│   ├── AEP_6_4_003_Genre_Style_Coverage.md
│   ├── AEP_6_4_004_Language_Coverage.md
│   ├── AEP_6_4_005_Quality_Tier_Labeling.md
│   ├── AEP_6_4_006_Duration_Coverage.md
│   ├── AEP_6_4_007_Metadata_Registry.md
│   └── AEP_6_4_008_Coverage_Gap_And_Roadmap.md
├── GATES/
│   └── Gate_Sample_Library_Coverage_6_4.md
├── PROMPTS/
│   ├── Claude_Execution_Prompt.md
│   └── Codex_Implementation_Prompt.md
├── REPORT_TEMPLATE/
│   └── Sample_Library_Coverage_Report_Template.md
├── CONFIG_SUGGESTIONS/
│   └── sample_library_config_suggestions.md
├── CHECKLISTS/
│   └── Execution_Checklist.md
├── DATA_SCHEMA/
│   └── sample_library_metadata_schema.json
├── MATRICES/
│   ├── Coverage_Matrix_Template.md
│   └── Minimum_Viable_Sample_Set.md
├── REGISTRY_TEMPLATE/
│   └── sample_registry_template.jsonl
└── SCRIPTS_SUGGESTIONS/
    └── suggested_sample_library_scripts.md
```

---

## 最终产出

本节点完成后，应该得到：

1. Moodify 样本分类体系。
2. 样本库 metadata schema。
3. 样本覆盖矩阵。
4. 最小可用样本集标准。
5. 样本缺口报告。
6. 样本注册表模板。
7. 样本采集与入库规范。
8. 下一阶段样本扩展路线图。
